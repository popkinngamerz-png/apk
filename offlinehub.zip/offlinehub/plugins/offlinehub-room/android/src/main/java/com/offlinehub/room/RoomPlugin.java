package com.offlinehub.room;

import android.content.Context;
import android.net.wifi.WifiManager;
import com.getcapacitor.JSObject;
import com.getcapacitor.Plugin;
import com.getcapacitor.PluginCall;
import com.getcapacitor.PluginMethod;
import com.getcapacitor.annotation.CapacitorPlugin;
import java.util.List;
import org.json.JSONArray;
import org.json.JSONObject;

/** Thin Capacitor wrapper around RoomNet. All real work happens in RoomNet. */
@CapacitorPlugin(name = "OfflineRoom")
public class RoomPlugin extends Plugin {
    // Static on purpose: if Android recreates the screen, the new plugin object can still stop the old room.
    private static final RoomNet NET = new RoomNet();
    private static volatile RoomPlugin current;
    private static WifiManager.MulticastLock multicastLock;

    private void attach() {
        current = this;
        NET.setEvents(new RoomNet.Events() {
            @Override
            public void onEvent(String name, String connId, String line) {
                RoomPlugin p = current;
                if (p == null) return;
                JSObject data = new JSObject();
                if (connId != null) data.put("connId", connId);
                if (line != null) data.put("line", line);
                p.notifyListeners(name, data);
            }
        });
        NET.setHostHooks(new Runnable() {
            @Override
            public void run() {
                setMulticastLock(true);
            }
        }, new Runnable() {
            @Override
            public void run() {
                setMulticastLock(false);
            }
        });
    }

    /** Some phones drop broadcast packets unless an app holds this lock while hosting. */
    private static void setMulticastLock(boolean on) {
        try {
            RoomPlugin p = current;
            if (on) {
                if (p == null) return;
                if (multicastLock == null) {
                    Context ctx = p.getContext().getApplicationContext();
                    WifiManager wm = (WifiManager) ctx.getSystemService(Context.WIFI_SERVICE);
                    multicastLock = wm.createMulticastLock("offlinehub-room");
                    multicastLock.setReferenceCounted(false);
                }
                multicastLock.acquire();
            } else if (multicastLock != null && multicastLock.isHeld()) {
                multicastLock.release();
            }
        } catch (Exception ignored) {
            // Hosting still works; only discovery on some phones may be affected.
        }
    }

    @PluginMethod
    public void getLocalAddresses(PluginCall call) {
        try {
            JSONArray arr = new JSONArray();
            for (String a : RoomNet.localAddresses()) arr.put(a);
            JSONObject o = new JSONObject();
            o.put("addresses", arr);
            call.resolve(new JSObject(o.toString()));
        } catch (Exception e) {
            call.reject("Could not read this phone's network address");
        }
    }

    @PluginMethod
    public void startHost(PluginCall call) {
        attach();
        String code = call.getString("code");
        if (code == null || !code.matches("[0-9]{6}")) {
            call.reject("The room code must be 6 digits");
            return;
        }
        try {
            int port = NET.startHost(code);
            JSObject r = new JSObject();
            r.put("port", port);
            call.resolve(r);
        } catch (Exception e) {
            call.reject("Could not open the room: " + e.getMessage());
        }
    }

    @PluginMethod
    public void stopHost(PluginCall call) {
        NET.stopHost();
        call.resolve();
    }

    @PluginMethod
    public void hostSend(PluginCall call) {
        try {
            NET.hostSend(call.getString("connId"), call.getString("line"));
            call.resolve();
        } catch (Exception e) {
            call.reject(String.valueOf(e.getMessage()));
        }
    }

    @PluginMethod
    public void hostClose(PluginCall call) {
        String id = call.getString("connId");
        if (id != null) NET.hostClose(id);
        call.resolve();
    }

    @PluginMethod
    public void discover(final PluginCall call) {
        attach();
        String code = call.getString("code");
        Integer t = call.getInt("timeoutMs");
        int timeout = t == null ? 4000 : Math.max(500, Math.min(10000, t));
        if (code == null || !code.matches("[0-9]{6}")) {
            call.reject("The room code must be 6 digits");
            return;
        }
        NET.discover(code, timeout, null, new RoomNet.Result<List<String[]>>() {
            @Override
            public void ok(List<String[]> hosts) {
                try {
                    JSONArray arr = new JSONArray();
                    for (String[] h : hosts) {
                        JSONObject one = new JSONObject();
                        one.put("ip", h[0]);
                        one.put("port", Integer.parseInt(h[1]));
                        arr.put(one);
                    }
                    JSONObject o = new JSONObject();
                    o.put("hosts", arr);
                    call.resolve(new JSObject(o.toString()));
                } catch (Exception e) {
                    call.reject("Could not read the search result");
                }
            }

            @Override
            public void fail(String message) {
                call.reject(message);
            }
        });
    }

    @PluginMethod
    public void connect(final PluginCall call) {
        attach();
        String ip = call.getString("ip");
        Integer port = call.getInt("port");
        if (ip == null || !ip.matches("^[0-9]{1,3}(\\.[0-9]{1,3}){3}$") || port == null || port < 1024 || port > 65535) {
            call.reject("Enter a valid host address");
            return;
        }
        NET.connect(ip, port, new RoomNet.Result<Void>() {
            @Override
            public void ok(Void v) {
                call.resolve();
            }

            @Override
            public void fail(String message) {
                call.reject(message);
            }
        });
    }

    @PluginMethod
    public void guestSend(PluginCall call) {
        try {
            NET.guestSend(call.getString("line"));
            call.resolve();
        } catch (Exception e) {
            call.reject(String.valueOf(e.getMessage()));
        }
    }

    @PluginMethod
    public void disconnect(PluginCall call) {
        NET.disconnect();
        call.resolve();
    }
}
