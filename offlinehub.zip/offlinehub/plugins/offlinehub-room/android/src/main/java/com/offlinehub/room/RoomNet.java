package com.offlinehub.room;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.Inet4Address;
import java.net.InetAddress;
import java.net.InetSocketAddress;
import java.net.InterfaceAddress;
import java.net.NetworkInterface;
import java.net.ServerSocket;
import java.net.Socket;
import java.net.SocketTimeoutException;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Enumeration;
import java.util.HashSet;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.LinkedBlockingQueue;

/**
 * Plain-Java networking for OfflineHub rooms. No Android or Capacitor classes in here.
 *
 * Phones talk over TCP, one JSON message per line. To find a host from only a
 * 6-digit code, guests broadcast a small UDP question on the local network and the
 * host answers only if the code matches. Nothing here ever leaves the local network.
 */
public final class RoomNet {
    public static final int TCP_PORT = 47653;
    public static final int UDP_PORT = 47654;
    static final int MAX_LINE_BYTES = 16 * 1024;
    static final int MAX_CONNECTIONS = 12;
    static final int MAX_QUEUED_LINES = 500;
    static final int UDP_LOCK_MS = 30_000;
    static final int UDP_STRIKE_LIMIT = 10;
    static final int UDP_WINDOW_MS = 60_000;

    /** Receives everything that happens on the network, from background threads. */
    public interface Events {
        void onEvent(String name, String connId, String line);
    }

    public interface Result<T> {
        void ok(T value);

        void fail(String message);
    }

    private static final byte[] CLOSE = new byte[0];

    /** How long a new connection may take to send its first line (package-private so tests can shorten it). */
    volatile int firstLineTimeoutMs = 10_000;

    private volatile Events events = new Events() {
        @Override
        public void onEvent(String name, String connId, String line) {
        }
    };
    private volatile Runnable hostStarted = new Runnable() {
        @Override
        public void run() {
        }
    };
    private volatile Runnable hostStopped = hostStarted;
    private final Object guestLock = new Object();
    private final Object udpLock = new Object();

    private ServerSocket server;
    private DatagramSocket udp;
    private volatile String hostCode;
    private volatile int hostPort;
    private final Map<String, Conn> hostConns = new ConcurrentHashMap<>();
    private long udpLockedUntil;
    private long udpWindowStart;
    private int udpStrikes;
    private Conn guest;

    public void setEvents(Events e) {
        events = e;
    }

    /** Called when hosting starts / stops (the Android plugin uses it for the Wi-Fi multicast lock). */
    public void setHostHooks(Runnable started, Runnable stopped) {
        hostStarted = started;
        hostStopped = stopped;
    }

    // ------------------------------------------------------------------ connections

    private final class Conn {
        final String id;
        final Socket socket;
        final LinkedBlockingQueue<byte[]> out = new LinkedBlockingQueue<>();
        volatile boolean dead;

        Conn(String id, Socket socket) {
            this.id = id;
            this.socket = socket;
        }

        void send(String line) {
            if (dead) return;
            if (out.size() > MAX_QUEUED_LINES) { // peer is not reading: drop it
                closeNow();
                return;
            }
            out.offer(line.getBytes(StandardCharsets.UTF_8));
        }

        /** Sends everything already queued, then closes. */
        void closeAfterFlush() {
            if (!dead) out.offer(CLOSE);
        }

        void closeNow() {
            dead = true;
            try {
                socket.close();
            } catch (IOException ignored) {
            }
            out.offer(CLOSE);
        }

        void startWriter() {
            Thread t = new Thread(new Runnable() {
                @Override
                public void run() {
                    try {
                        OutputStream os = new BufferedOutputStream(socket.getOutputStream());
                        while (true) {
                            byte[] b = out.take();
                            if (b == CLOSE) break;
                            os.write(b);
                            os.write('\n');
                            os.flush();
                        }
                    } catch (Exception ignored) {
                    } finally {
                        closeNow();
                    }
                }
            }, "oh-write-" + id);
            t.setDaemon(true);
            t.start();
        }
    }

    private interface LineSink {
        void onLine(String line);
    }

    /** Reads newline-separated lines. Drops the connection if a line is too long or the first line is too slow. */
    private void readLoop(Conn c, int firstLineTimeout, LineSink sink, Runnable onEnd) {
        try {
            InputStream in = new BufferedInputStream(c.socket.getInputStream());
            ByteArrayOutputStream buf = new ByteArrayOutputStream();
            boolean first = firstLineTimeout > 0;
            long deadline = System.currentTimeMillis() + firstLineTimeout;
            c.socket.setSoTimeout(first ? firstLineTimeout : 0);
            int b;
            while ((b = in.read()) != -1) {
                if (b == '\n') {
                    String line = new String(buf.toByteArray(), StandardCharsets.UTF_8);
                    buf.reset();
                    if (first) {
                        first = false;
                        c.socket.setSoTimeout(0);
                    }
                    sink.onLine(line);
                } else if (b != '\r') {
                    if (buf.size() >= MAX_LINE_BYTES) break;
                    if (first && System.currentTimeMillis() > deadline) break;
                    buf.write(b);
                }
            }
        } catch (Exception ignored) {
        } finally {
            onEnd.run();
        }
    }

    private static void checkLine(String line) {
        if (line == null || line.length() == 0) throw new IllegalArgumentException("Empty line");
        if (line.indexOf('\n') >= 0 || line.indexOf('\r') >= 0) throw new IllegalArgumentException("Line breaks are not allowed");
        if (line.getBytes(StandardCharsets.UTF_8).length > MAX_LINE_BYTES) throw new IllegalArgumentException("Line too long");
    }

    // ------------------------------------------------------------------ host

    /** Opens the room. Returns the TCP port guests connect to. */
    public synchronized int startHost(String code) throws IOException {
        stopHost();
        ServerSocket ss = new ServerSocket();
        ss.setReuseAddress(true);
        try {
            ss.bind(new InetSocketAddress(TCP_PORT));
        } catch (IOException busy) {
            ss.close();
            ss = new ServerSocket();
            ss.setReuseAddress(true);
            ss.bind(new InetSocketAddress(0));
        }
        final ServerSocket srv = ss;

        DatagramSocket ds = null;
        try { // discovery is best effort: joining by IP address still works without it
            ds = new DatagramSocket(null);
            ds.setReuseAddress(true);
            ds.setBroadcast(true);
            ds.bind(new InetSocketAddress(UDP_PORT));
        } catch (Exception e) {
            if (ds != null) ds.close();
            ds = null;
        }
        final DatagramSocket dsock = ds;

        server = srv;
        udp = dsock;
        hostCode = code;
        hostPort = srv.getLocalPort();
        synchronized (udpLock) {
            udpStrikes = 0;
            udpLockedUntil = 0;
            udpWindowStart = 0;
        }

        Thread accept = new Thread(new Runnable() {
            @Override
            public void run() {
                while (!srv.isClosed()) {
                    try {
                        handleAccepted(srv.accept());
                    } catch (Exception e) {
                        if (srv.isClosed()) break;
                    }
                }
            }
        }, "oh-accept");
        accept.setDaemon(true);
        accept.start();

        if (dsock != null) {
            Thread responder = new Thread(new Runnable() {
                @Override
                public void run() {
                    answerDiscovery(dsock);
                }
            }, "oh-discovery");
            responder.setDaemon(true);
            responder.start();
        }
        hostStarted.run();
        return hostPort;
    }

    public synchronized void stopHost() {
        boolean was = server != null || udp != null;
        hostCode = null;
        if (server != null) {
            try {
                server.close();
            } catch (IOException ignored) {
            }
            server = null;
        }
        if (udp != null) {
            udp.close();
            udp = null;
        }
        for (Conn c : hostConns.values()) c.closeNow();
        hostConns.clear();
        if (was) hostStopped.run();
    }

    private void handleAccepted(Socket s) {
        if (hostConns.size() >= MAX_CONNECTIONS) {
            try {
                s.close();
            } catch (IOException ignored) {
            }
            return;
        }
        try {
            s.setTcpNoDelay(true);
        } catch (IOException ignored) {
        }
        final Conn c = new Conn(UUID.randomUUID().toString(), s);
        hostConns.put(c.id, c);
        c.startWriter();
        events.onEvent("hostConn", c.id, null);
        Thread reader = new Thread(new Runnable() {
            @Override
            public void run() {
                readLoop(c, firstLineTimeoutMs, new LineSink() {
                    @Override
                    public void onLine(String line) {
                        events.onEvent("hostLine", c.id, line);
                    }
                }, new Runnable() {
                    @Override
                    public void run() {
                        c.closeNow();
                        if (hostConns.remove(c.id) != null) events.onEvent("hostClosed", c.id, null);
                    }
                });
            }
        }, "oh-host-read");
        reader.setDaemon(true);
        reader.start();
    }

    public void hostSend(String connId, String line) {
        checkLine(line);
        Conn c = hostConns.get(connId);
        if (c != null) c.send(line);
    }

    /** Closes one guest connection after everything already queued for it has been sent. */
    public void hostClose(String connId) {
        Conn c = hostConns.get(connId);
        if (c != null) c.closeAfterFlush();
    }

    public int hostConnectionCount() {
        return hostConns.size();
    }

    private void answerDiscovery(DatagramSocket ds) {
        byte[] buf = new byte[128];
        while (!ds.isClosed()) {
            try {
                DatagramPacket p = new DatagramPacket(buf, buf.length);
                ds.receive(p);
                String msg = new String(p.getData(), 0, p.getLength(), StandardCharsets.UTF_8);
                String code = hostCode;
                if (code == null || !msg.startsWith("OHUB1|")) continue;
                long now = System.currentTimeMillis();
                synchronized (udpLock) {
                    if (now < udpLockedUntil) continue;
                    if (!msg.substring(6).equals(code)) {
                        if (now - udpWindowStart > UDP_WINDOW_MS) {
                            udpWindowStart = now;
                            udpStrikes = 0;
                        }
                        udpStrikes++;
                        if (udpStrikes >= UDP_STRIKE_LIMIT) {
                            udpStrikes = 0;
                            udpLockedUntil = now + UDP_LOCK_MS;
                        }
                        continue;
                    }
                }
                byte[] reply = ("OHUB1R|" + hostPort).getBytes(StandardCharsets.UTF_8);
                ds.send(new DatagramPacket(reply, reply.length, p.getAddress(), p.getPort()));
            } catch (Exception e) {
                if (ds.isClosed()) break;
            }
        }
    }

    // ------------------------------------------------------------------ guest

    /** Looks for a host with this code on the local network. Each result is {ip, port}. */
    public void discover(final String code, final int timeoutMs, final List<String> extraTargets, final Result<List<String[]>> result) {
        Thread t = new Thread(new Runnable() {
            @Override
            public void run() {
                DatagramSocket ds = null;
                try {
                    ds = new DatagramSocket();
                    ds.setBroadcast(true);
                    ds.setSoTimeout(250);
                    byte[] msg = ("OHUB1|" + code).getBytes(StandardCharsets.UTF_8);
                    List<InetAddress> targets = broadcastTargets(extraTargets);
                    List<String[]> found = new ArrayList<>();
                    Set<String> seen = new HashSet<>();
                    byte[] buf = new byte[128];
                    long end = System.currentTimeMillis() + timeoutMs;
                    long nextSend = 0;
                    while (found.isEmpty() && System.currentTimeMillis() < end) {
                        long now = System.currentTimeMillis();
                        if (now >= nextSend) { // UDP can be lost, so ask again every 700 ms
                            for (InetAddress a : targets) {
                                try {
                                    ds.send(new DatagramPacket(msg, msg.length, a, UDP_PORT));
                                } catch (IOException ignored) {
                                }
                            }
                            nextSend = now + 700;
                        }
                        try {
                            DatagramPacket p = new DatagramPacket(buf, buf.length);
                            ds.receive(p);
                            String r = new String(p.getData(), 0, p.getLength(), StandardCharsets.UTF_8);
                            if (r.startsWith("OHUB1R|")) {
                                int port = parsePort(r.substring(7));
                                String ip = p.getAddress().getHostAddress();
                                if (port > 0 && seen.add(ip + ":" + port)) found.add(new String[] {ip, String.valueOf(port)});
                            }
                        } catch (SocketTimeoutException ignored) {
                        }
                    }
                    result.ok(found);
                } catch (Exception e) {
                    result.fail("Could not search the network");
                } finally {
                    if (ds != null) ds.close();
                }
            }
        }, "oh-discover");
        t.setDaemon(true);
        t.start();
    }

    private static int parsePort(String s) {
        try {
            int p = Integer.parseInt(s.trim());
            return p >= 1024 && p <= 65535 ? p : -1;
        } catch (NumberFormatException e) {
            return -1;
        }
    }

    private static List<InetAddress> broadcastTargets(List<String> extra) {
        Set<String> names = new LinkedHashSet<>();
        names.add("255.255.255.255");
        try {
            Enumeration<NetworkInterface> en = NetworkInterface.getNetworkInterfaces();
            while (en != null && en.hasMoreElements()) {
                NetworkInterface ni = en.nextElement();
                if (!ni.isUp() || ni.isLoopback()) continue;
                for (InterfaceAddress ia : ni.getInterfaceAddresses()) {
                    InetAddress b = ia.getBroadcast();
                    if (b != null) names.add(b.getHostAddress());
                }
            }
        } catch (Exception ignored) {
        }
        if (extra != null) names.addAll(extra);
        List<InetAddress> out = new ArrayList<>();
        for (String n : names) {
            try {
                out.add(InetAddress.getByName(n)); // numeric addresses only: no DNS lookup happens
            } catch (Exception ignored) {
            }
        }
        return out;
    }

    /** This phone's local IPv4 addresses, private ranges first (shown to the host for joining by IP). */
    public static List<String> localAddresses() {
        List<String> priv = new ArrayList<>();
        List<String> other = new ArrayList<>();
        try {
            Enumeration<NetworkInterface> en = NetworkInterface.getNetworkInterfaces();
            while (en != null && en.hasMoreElements()) {
                NetworkInterface ni = en.nextElement();
                if (!ni.isUp() || ni.isLoopback()) continue;
                Enumeration<InetAddress> addrs = ni.getInetAddresses();
                while (addrs.hasMoreElements()) {
                    InetAddress a = addrs.nextElement();
                    if (!(a instanceof Inet4Address) || a.isLoopbackAddress() || a.isLinkLocalAddress()) continue;
                    (a.isSiteLocalAddress() ? priv : other).add(a.getHostAddress());
                }
            }
        } catch (Exception ignored) {
        }
        priv.addAll(other);
        return priv;
    }

    /** Connects to a host. Lines from the host arrive as "guestLine" events, a drop as "guestClosed". */
    public void connect(final String ip, final int port, final Result<Void> result) {
        Thread t = new Thread(new Runnable() {
            @Override
            public void run() {
                Socket s = new Socket();
                try {
                    s.connect(new InetSocketAddress(ip, port), 4000);
                    s.setTcpNoDelay(true);
                } catch (Exception e) {
                    try {
                        s.close();
                    } catch (IOException ignored) {
                    }
                    result.fail("Could not reach the host");
                    return;
                }
                final Conn c = new Conn("guest", s);
                synchronized (guestLock) {
                    Conn old = guest;
                    guest = c;
                    if (old != null) old.closeNow();
                }
                c.startWriter();
                result.ok(null);
                readLoop(c, 0, new LineSink() {
                    @Override
                    public void onLine(String line) {
                        events.onEvent("guestLine", null, line);
                    }
                }, new Runnable() {
                    @Override
                    public void run() {
                        c.closeNow();
                        boolean mine;
                        synchronized (guestLock) {
                            mine = guest == c;
                            if (mine) guest = null;
                        }
                        if (mine) events.onEvent("guestClosed", null, null);
                    }
                });
            }
        }, "oh-guest");
        t.setDaemon(true);
        t.start();
    }

    public void guestSend(String line) {
        checkLine(line);
        Conn c;
        synchronized (guestLock) {
            c = guest;
        }
        if (c == null) throw new IllegalStateException("Not connected");
        c.send(line);
    }

    /** Leaves the room after everything already queued has been sent. */
    public void disconnect() {
        Conn c;
        synchronized (guestLock) {
            c = guest;
            guest = null;
        }
        if (c != null) c.closeAfterFlush();
    }
}
