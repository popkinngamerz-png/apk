import { DatabaseSync } from "node:sqlite";
import type { Db, SqlValue } from "../src/core/db.ts";

/** Test-only adapter: real SQLite (node:sqlite) behind the same Db interface the app uses. */
export class NodeDb implements Db {
  raw: DatabaseSync;
  private depth = 0;
  constructor(path = ":memory:") {
    this.raw = new DatabaseSync(path);
  }
  async run(sql: string, params: SqlValue[] = []): Promise<void> {
    this.raw.prepare(sql).run(...params);
  }
  async all<T = Record<string, any>>(sql: string, params: SqlValue[] = []): Promise<T[]> {
    return this.raw.prepare(sql).all(...params) as T[];
  }
  async transaction<T>(fn: () => Promise<T>): Promise<T> {
    if (this.depth > 0) return fn();
    this.depth++;
    this.raw.exec("BEGIN");
    try {
      const r = await fn();
      this.raw.exec("COMMIT");
      return r;
    } catch (e) {
      this.raw.exec("ROLLBACK");
      throw e;
    } finally {
      this.depth--;
    }
  }
  close(): void {
    this.raw.close();
  }
}
