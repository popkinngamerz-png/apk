import assert from "node:assert/strict";
import { test } from "node:test";
import { generateRoomCode, isValidCodeFormat, normalizeCodeInput } from "../src/room/code.ts";
import { RoomHost, type HostEvent } from "../src/room/host.ts";
import { MAX_GUESTS } from "../src/room/protocol.ts";
import { INFO, connect } from "./memoryTransport.ts";

function newHost(now = () => 0) {
  return new RoomHost({ hostName: "Host", hostColor: "#5865f2", code: "123456", now });
}

test("room code: always 6 digits, keeps leading zeros, uniform (rejects bytes >= 250)", () => {
  for (let i = 0; i < 200; i++) assert.match(generateRoomCode(), /^[0-9]{6}$/);
  assert.equal(generateRoomCode(() => new Uint8Array(16)), "000000");
  // bytes 250-255 must be skipped, so only the 9s at the end are used
  const bytes = [255, 250, 251, 9, 9, 9, 9, 9, 9, 0, 0, 0, 0, 0, 0, 0];
  assert.equal(generateRoomCode(() => Uint8Array.from(bytes)), "999999");
  assert.ok(isValidCodeFormat("012345"));
  assert.ok(!isValidCodeFormat("12345") && !isValidCodeFormat("1234567") && !isValidCodeFormat("12345a") && !isValidCodeFormat(123456));
  assert.equal(normalizeCodeInput("123 456"), "123456");
  assert.equal(normalizeCodeInput("12-34-56-78"), "123456");
});

test("starts at 0/4, guest joins with right code, counter and member list update", () => {
  const host = newHost();
  assert.equal(host.guestCount, 0);
  assert.equal(host.maxGuests, 4);
  const a = connect(host, "123456", INFO("Ana"));
  a.guest.join();
  assert.equal(a.guest.snapshot.state, "joined");
  assert.equal(a.guest.snapshot.guests, 1);
  assert.equal(a.guest.snapshot.max, 4);
  assert.deepEqual(a.guest.snapshot.members.map((m) => m.displayName), ["Host", "Ana"]);
  assert.equal(host.guestCount, 1);
  const b = connect(host, "123456", INFO("Ben"));
  b.guest.join();
  assert.equal(host.guestCount, 2);
  assert.equal(a.guest.snapshot.guests, 2, "existing guest is told about the new member");
});

test("wrong code is rejected and nobody is added", () => {
  const host = newHost();
  const a = connect(host, "000000", INFO("Eve"));
  a.guest.join();
  assert.equal(a.guest.snapshot.state, "rejected");
  assert.equal(a.guest.snapshot.rejectReason, "bad_code");
  assert.equal(host.guestCount, 0);
});

test("the 5th guest is refused (full), and a freed seat can be used again", () => {
  const host = newHost();
  const links = Array.from({ length: MAX_GUESTS }, (_, i) => connect(host, "123456", INFO(`G${i}`)));
  links.forEach((l) => l.guest.join());
  assert.equal(host.guestCount, 4);
  const extra = connect(host, "123456", INFO("Late"));
  extra.guest.join();
  assert.equal(extra.guest.snapshot.state, "rejected");
  assert.equal(extra.guest.snapshot.rejectReason, "full");
  assert.equal(host.guestCount, 4);
  links[0].guest.leave();
  assert.equal(host.guestCount, 3);
  const again = connect(host, "123456", INFO("Late2"));
  again.guest.join();
  assert.equal(again.guest.snapshot.state, "joined");
  assert.equal(host.guestCount, 4);
});

test("a full room does not reveal itself to someone with the wrong code", () => {
  const host = newHost();
  for (let i = 0; i < 4; i++) connect(host, "123456", INFO(`G${i}`)).guest.join();
  const spy = connect(host, "999999", INFO("Spy"));
  spy.guest.join();
  assert.equal(spy.guest.snapshot.rejectReason, "bad_code");
});

test("chat reaches host and every guest; late joiner gets history", () => {
  const host = newHost();
  const seen: HostEvent[] = [];
  host.subscribe((e) => seen.push(e));
  const a = connect(host, "123456", INFO("Ana"));
  const b = connect(host, "123456", INFO("Ben"));
  a.guest.join();
  b.guest.join();
  assert.ok(a.guest.sendChat("hello all"));
  assert.ok(host.sendHostChat("welcome"));
  assert.deepEqual(b.guest.snapshot.messages.map((m) => `${m.fromName}: ${m.body}`), ["Ana: hello all", "Host: welcome"]);
  assert.deepEqual(seen.filter((e) => e.t === "chat").map((e) => (e as any).msg.body), ["hello all", "welcome"]);
  const c = connect(host, "123456", INFO("Cy"));
  c.guest.join();
  assert.equal(c.guest.snapshot.messages.length, 2);
});

test("chat from a connection that has not joined is ignored", () => {
  const host = newHost();
  const x = connect(host, "123456", INFO("Sneaky"));
  x.raw({ t: "chat", body: "let me in" });
  assert.equal(host.guestCount, 0);
  const seen: HostEvent[] = [];
  host.subscribe((e) => seen.push(e));
  x.raw({ t: "chat", body: "again" });
  assert.equal(seen.length, 0);
});

test("bad input: empty/oversized chat, bad join info, garbage messages", () => {
  const host = newHost();
  const a = connect(host, "123456", INFO("Ana"));
  a.guest.join();
  assert.ok(!a.guest.sendChat("   "));
  assert.ok(!a.guest.sendChat("x".repeat(2001)));
  a.raw({ t: "chat", body: 42 });
  a.raw("not an object");
  a.raw(null);
  a.raw({ t: "nonsense" });
  assert.equal(a.guest.snapshot.messages.length, 0);
  const bad = connect(host, "123456", { displayName: "Bob", avatarColor: "red" });
  bad.guest.join();
  assert.equal(bad.guest.snapshot.rejectReason, "bad_request");
  const noName = connect(host, "123456", { displayName: "  ", avatarColor: "#ffffff" });
  noName.guest.join();
  assert.equal(noName.guest.snapshot.rejectReason, "bad_request");
  assert.equal(host.guestCount, 1);
});

test("3 wrong codes on one connection drops it", () => {
  const host = newHost();
  const x = connect(host, "000000", INFO("Brute"));
  x.raw({ t: "join", code: "111111", info: INFO("Brute") });
  x.raw({ t: "join", code: "222222", info: INFO("Brute") });
  assert.ok(!x.closed());
  x.raw({ t: "join", code: "333333", info: INFO("Brute") });
  assert.ok(x.closed());
});

test("10 wrong codes lock joins for 30 s, even for the right code, then unlock", () => {
  let t = 1000;
  const host = newHost(() => t);
  for (let i = 0; i < 10; i++) connect(host, "000000", INFO("Brute")).guest.join();
  const good = connect(host, "123456", INFO("Real"));
  good.guest.join();
  assert.equal(good.guest.snapshot.rejectReason, "locked");
  t += 29_000;
  const still = connect(host, "123456", INFO("Real"));
  still.guest.join();
  assert.equal(still.guest.snapshot.rejectReason, "locked");
  t += 2_000;
  const ok = connect(host, "123456", INFO("Real"));
  ok.guest.join();
  assert.equal(ok.guest.snapshot.state, "joined");
});

test("host closing the room tells guests and empties it; dropped connection updates counter", () => {
  const host = newHost();
  const a = connect(host, "123456", INFO("Ana"));
  const b = connect(host, "123456", INFO("Ben"));
  a.guest.join();
  b.guest.join();
  b.conn.close(); // phone lost the connection without saying goodbye
  assert.equal(host.guestCount, 1);
  assert.equal(a.guest.snapshot.guests, 1);
  host.close();
  assert.equal(a.guest.snapshot.state, "closed");
  assert.equal(host.guestCount, 0);
  assert.ok(!host.open);
  assert.ok(!host.sendHostChat("anyone?"));
  const late = connect(host, "123456", INFO("Late"));
  late.guest.join();
  assert.notEqual(late.guest.snapshot.state, "joined");
});
