import test from "node:test";
import assert from "node:assert/strict";
import { mkdtempSync, readFileSync, readdirSync, statSync } from "node:fs";
import { join } from "node:path";
import { tmpdir } from "node:os";
import { expectCode, newHub, OWNER_PW, setupWithOwner } from "./helpers.ts";

test("data survives an app restart (new connection on the same database file)", async () => {
  const path = join(mkdtempSync(join(tmpdir(), "oh-")), "app.db");
  const a = await setupWithOwner(path);
  await a.hub.register("alice", "Alice", "alice-pass-1");
  a.hub.logout();
  await a.hub.login("alice", "alice-pass-1");
  const ws = await a.hub.createWorkspace("Club");
  const ch = (await a.hub.listChannels(ws.id))[0];
  await a.hub.sendMessage(ch.id, "persist me");
  a.db.close();

  const b = await newHub(path); // "restart"
  assert.equal(await b.hub.isFirstRun(), false);
  await b.hub.login("alice", "alice-pass-1");
  assert.equal((await b.hub.myWorkspaces()).length, 1);
  assert.equal((await b.hub.listMessages(ch.id))[0].body, "persist me");
  b.db.close();
});

test("migrations are idempotent", async () => {
  const path = join(mkdtempSync(join(tmpdir(), "oh-")), "m.db");
  const a = await newHub(path);
  a.db.close();
  const b = await newHub(path);
  const v = await b.db.all<any>("SELECT COUNT(*) AS n FROM schema_migrations");
  assert.equal(v[0].n, 1);
  b.db.close();
});

test("backup -> change data -> restore returns exact earlier state; restore forces re-login", async () => {
  const { hub, db } = await setupWithOwner();
  await hub.createUser({ username: "carol", displayName: "Carol", password: "password-123", memberSince: "2018-03-03" });
  const ws = await hub.createWorkspace("Club");
  const ch = (await hub.listChannels(ws.id))[0];
  await hub.sendMessage(ch.id, "before");
  const backup = await hub.exportBackup();
  const usersBefore = JSON.stringify((await db.all("SELECT * FROM users ORDER BY id")));

  await hub.sendMessage(ch.id, "after");
  await hub.createUser({ username: "dave", displayName: "Dave", password: "password-123" });
  await expectCode(hub.restoreBackup(backup, "no"), "CONFIRMATION_FAILED");
  await hub.restoreBackup(backup, "RESTORE");

  assert.equal(await hub.currentUser(), null);
  assert.equal(JSON.stringify(await db.all("SELECT * FROM users ORDER BY id")), usersBefore);
  await hub.login("carol", "password-123");
  hub.logout();
  await hub.login("boss", OWNER_PW);
  assert.deepEqual((await hub.listMessages(ch.id)).map((m) => m.body), ["before"]);
  await hub.unlockAdmin(OWNER_PW);
  assert.ok((await hub.listAudit()).some((a) => a.action === "backup.restore"));
});

test("invalid or dangerous backups are rejected and leave data untouched", async () => {
  const { hub } = await setupWithOwner();
  const good = JSON.parse(await hub.exportBackup());
  const bad = (mutate: (d: any) => void) => {
    const d = JSON.parse(JSON.stringify(good));
    mutate(d);
    return JSON.stringify(d);
  };
  await expectCode(hub.restoreBackup("not json", "RESTORE"), "INVALID_BACKUP");
  await expectCode(hub.restoreBackup("{}", "RESTORE"), "INVALID_BACKUP");
  await expectCode(hub.restoreBackup(bad((d) => (d.version = 99)), "RESTORE"), "INVALID_BACKUP");
  await expectCode(hub.restoreBackup(bad((d) => d.tables.users.forEach((u: any) => (u.is_owner = 0))), "RESTORE"), "INVALID_BACKUP");
  await expectCode(hub.restoreBackup(bad((d) => (d.tables.users[0].extra = "x")), "RESTORE"), "INVALID_BACKUP");
  await expectCode(hub.restoreBackup(bad((d) => (d.tables.users[0].status = "god")), "RESTORE"), "INVALID_BACKUP");
  await expectCode(hub.restoreBackup(bad((d) => (d.tables.users[0].bio = { a: 1 })), "RESTORE"), "INVALID_BACKUP");
  assert.equal((await hub.listUsers()).length, 1);
});

test("a failed restore rolls back completely", async () => {
  const { hub } = await setupWithOwner();
  await hub.createUser({ username: "carol", displayName: "Carol", password: "password-123" });
  const good = JSON.parse(await hub.exportBackup());
  // Duplicate primary key makes the INSERT fail midway: everything must roll back.
  good.tables.users.push({ ...good.tables.users[0], is_owner: 0 });
  await assert.rejects(hub.restoreBackup(JSON.stringify(good), "RESTORE"));
  assert.equal((await hub.listUsers()).length, 2);
});

test("core source makes no network calls (offline guarantee, static check)", () => {
  const bad = [/\bfetch\s*\(/, /XMLHttpRequest/, /\bWebSocket\b/, /EventSource/, /sendBeacon/, /https?:\/\//];
  const hits: string[] = [];
  const walk = (dir: string) => {
    for (const f of readdirSync(dir)) {
      const p = join(dir, f);
      if (statSync(p).isDirectory()) walk(p);
      else if (/\.(ts|tsx|html|css)$/.test(f)) {
        const src = readFileSync(p, "utf8");
        for (const re of bad) if (re.test(src)) hits.push(`${p}: ${re}`);
      }
    }
  };
  walk(join(process.cwd(), "src"));
  const html = readFileSync(join(process.cwd(), "index.html"), "utf8");
  for (const re of bad) if (re.test(html)) hits.push(`index.html: ${re}`);
  assert.deepEqual(hits, []);
});
