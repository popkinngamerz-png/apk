import type { FoundHost, NativeHandle, NativeRoom } from "../src/room/nativeTypes.ts";

/**
 * Test-only stand-in for the Android plugin. Phones created from the same FakeNetwork can
 * find each other by code and exchange lines, with events delivered asynchronously and in
 * order, like the real plugin does.
 */
export class FakeNetwork {
  hosts = new Map<string, { phone: FakePhone; port: number }>(); // by room code
  byIp = new Map<string, FakePhone>();
  private nextIp = 2;
  phone(): FakePhone {
    const p = new FakePhone(this, `192.168.43.${this.nextIp++}`);
    this.byIp.set(p.ip, p);
    return p;
  }
  post(fn: () => void) {
    queueMicrotask(fn);
  }
}

export class FakePhone implements NativeRoom {
  listeners = new Map<string, Set<(d: any) => void>>();
  conns = new Map<string, FakePhone>(); // host side: connId -> guest phone
  guestOf: { host: FakePhone; connId: string } | null = null; // guest side
  hostCode: string | null = null;
  removedHandles = 0;
  nextConn = 1;
  net: FakeNetwork;
  ip: string;
  constructor(net: FakeNetwork, ip: string) {
    this.net = net;
    this.ip = ip;
  }

  emit(name: string, data: any) {
    for (const fn of this.listeners.get(name) ?? []) fn(data);
  }
  async addListener(name: string, fn: (d: any) => void): Promise<NativeHandle> {
    if (!this.listeners.has(name)) this.listeners.set(name, new Set());
    this.listeners.get(name)!.add(fn);
    return { remove: async () => { this.removedHandles++; this.listeners.get(name)!.delete(fn); } };
  }
  async getLocalAddresses() {
    return { addresses: [this.ip] };
  }
  async startHost(o: { code: string }) {
    this.hostCode = o.code;
    this.net.hosts.set(o.code, { phone: this, port: 47653 });
    return { port: 47653 };
  }
  async stopHost() {
    if (this.hostCode) this.net.hosts.delete(this.hostCode);
    this.hostCode = null;
    for (const [id, g] of this.conns) this.net.post(() => g.emit("guestClosed", {}));
    this.conns.clear();
  }
  async hostSend(o: { connId: string; line: string }) {
    const g = this.conns.get(o.connId);
    if (g) this.net.post(() => g.emit("guestLine", { line: o.line }));
  }
  async hostClose(o: { connId: string }) {
    const g = this.conns.get(o.connId);
    if (!g) return;
    this.conns.delete(o.connId);
    this.net.post(() => { g.emit("guestClosed", {}); this.emit("hostClosed", { connId: o.connId }); });
  }
  async discover(o: { code: string; timeoutMs: number }): Promise<{ hosts: FoundHost[] }> {
    const h = this.net.hosts.get(o.code);
    return { hosts: h ? [{ ip: h.phone.ip, port: h.port }] : [] };
  }
  async connect(o: { ip: string; port: number }) {
    const host = this.net.byIp.get(o.ip);
    if (!host || !host.hostCode) throw new Error("Could not reach the host");
    const connId = `c${host.nextConn++}`;
    host.conns.set(connId, this);
    this.guestOf = { host, connId };
    this.net.post(() => host.emit("hostConn", { connId }));
  }
  async guestSend(o: { line: string }) {
    const g = this.guestOf;
    if (g) this.net.post(() => g.host.emit("hostLine", { connId: g.connId, line: o.line }));
  }
  async disconnect() {
    const g = this.guestOf;
    this.guestOf = null;
    if (g) { g.host.conns.delete(g.connId); this.net.post(() => g.host.emit("hostClosed", { connId: g.connId })); }
  }
}

/** Lets queued events run. */
export const settle = () => new Promise<void>((r) => setTimeout(r, 0));
