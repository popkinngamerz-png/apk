import assert from "node:assert/strict";
import { test } from "node:test";
import { joinRoomSession, RoomNetError } from "../src/room/guestSession.ts";
import { startHostSession } from "../src/room/hostSession.ts";
import { FakeNetwork, settle } from "./fakeNative.ts";

const ME = (name: string) => ({ displayName: name, avatarColor: "#3ba55d" });

async function openRoom() {
  const net = new FakeNetwork();
  const hostPhone = net.phone();
  const session = await startHostSession(hostPhone, { hostName: "Host", hostColor: "#5865f2" });
  return { net, hostPhone, session };
}

test("host session opens a room with a 6-digit code and reports the phone's address", async () => {
  const { hostPhone, session } = await openRoom();
  assert.match(session.code, /^[0-9]{6}$/);
  assert.equal(hostPhone.hostCode, session.code);
  assert.equal(session.port, 47653);
  assert.deepEqual(session.addresses, [hostPhone.ip]);
  assert.equal(session.host.guestCount, 0);
});

test("a guest finds the room by code, joins, and chat works both ways", async () => {
  const { net, session } = await openRoom();
  const ana = await joinRoomSession(net.phone(), { code: session.code, info: ME("Ana") });
  const ben = await joinRoomSession(net.phone(), { code: session.code, info: ME("Ben") });
  await settle();
  assert.equal(ana.guest.snapshot.state, "joined");
  assert.equal(session.host.guestCount, 2);
  assert.equal(ana.guest.snapshot.guests, 2, "Ana is told Ben joined");
  assert.ok(ana.guest.sendChat("hi from Ana"));
  await settle(); // Ana's message reaches the host first
  assert.ok(session.host.sendHostChat("hi from host"));
  await settle();
  const texts = (g: typeof ben) => g.guest.snapshot.messages.map((m) => `${m.fromName}: ${m.body}`);
  assert.deepEqual(texts(ben), ["Ana: hi from Ana", "Host: hi from host"]);
  assert.deepEqual(texts(ana), ["Ana: hi from Ana", "Host: hi from host"]);
});

test("no room with that code: clear 'not_found' error", async () => {
  const net = new FakeNetwork();
  await assert.rejects(joinRoomSession(net.phone(), { code: "000000", info: ME("Ana") }), (e: unknown) => e instanceof RoomNetError && e.failure === "not_found");
});

test("joining by IP address with the wrong code is rejected; unreachable IP gives 'connect_failed'", async () => {
  const { net, hostPhone, session } = await openRoom();
  const wrong = await joinRoomSession(net.phone(), { code: "999999", info: ME("Eve"), ip: hostPhone.ip });
  await settle();
  assert.equal(wrong.guest.snapshot.state, "rejected");
  assert.equal(wrong.guest.snapshot.rejectReason, "bad_code");
  assert.equal(session.host.guestCount, 0);
  await assert.rejects(joinRoomSession(net.phone(), { code: session.code, info: ME("Eve"), ip: "10.9.9.9" }), (e: unknown) => e instanceof RoomNetError && e.failure === "connect_failed");
});

test("the 5th guest is told the room is full", async () => {
  const { net, session } = await openRoom();
  for (let i = 0; i < 4; i++) await joinRoomSession(net.phone(), { code: session.code, info: ME(`G${i}`) });
  await settle();
  assert.equal(session.host.guestCount, 4);
  const late = await joinRoomSession(net.phone(), { code: session.code, info: ME("Late") });
  await settle();
  assert.equal(late.guest.snapshot.rejectReason, "full");
});

test("garbage lines from the network are ignored", async () => {
  const { net, hostPhone, session } = await openRoom();
  const ana = await joinRoomSession(net.phone(), { code: session.code, info: ME("Ana") });
  await settle();
  hostPhone.emit("hostLine", { connId: "c1", line: "{not json" });
  hostPhone.emit("hostLine", { connId: "nope", line: "{}" });
  hostPhone.emit("hostLine", { connId: "c1", line: JSON.stringify({ t: "chat", body: "ok" }) });
  await settle();
  assert.equal(session.host.guestCount, 1);
  assert.equal(ana.guest.snapshot.messages.length, 1);
});

test("guest leaving frees the seat; host stopping closes guests and removes listeners", async () => {
  const { net, hostPhone, session } = await openRoom();
  const ana = await joinRoomSession(net.phone(), { code: session.code, info: ME("Ana") });
  const ben = await joinRoomSession(net.phone(), { code: session.code, info: ME("Ben") });
  await settle();
  await ana.leave();
  await settle();
  assert.equal(session.host.guestCount, 1);
  assert.equal(ben.guest.snapshot.guests, 1);
  await session.stop();
  await settle();
  assert.equal(ben.guest.snapshot.state, "closed");
  assert.ok(!session.host.open);
  assert.equal(hostPhone.hostCode, null);
  assert.equal(hostPhone.removedHandles, 3, "all three host listeners were removed");
  const noRoom = net.phone();
  await assert.rejects(joinRoomSession(noRoom, { code: session.code, info: ME("Late") }), (e: unknown) => e instanceof RoomNetError);
});
