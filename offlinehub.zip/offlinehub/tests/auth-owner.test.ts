import test from "node:test";
import assert from "node:assert/strict";
import { expectCode, makeClock, newHub, OWNER_PW, setupWithOwner } from "./helpers.ts";

test("fresh install has no accounts and no default login", async () => {
  const { hub } = await newHub();
  assert.equal(await hub.isFirstRun(), true);
  await expectCode(hub.login("admin", "admin"), "BAD_CREDENTIALS");
  await expectCode(hub.register("alice", "Alice", "password1"), "FORBIDDEN"); // setup first
});

test("owner setup works once, enforces a strong password, and cannot be repeated", async () => {
  const { hub } = await newHub();
  await expectCode(hub.setupOwner("boss", "Boss", "short"), "INVALID_INPUT");
  const o = await hub.setupOwner("boss", "Boss", OWNER_PW);
  assert.equal(o.isOwner, true);
  await expectCode(hub.setupOwner("evil", "Evil", "another-long-password"), "FORBIDDEN");
});

test("passwords are stored as salted PBKDF2 hashes, never plaintext", async () => {
  const { hub, db } = await setupWithOwner();
  await hub.register("alice", "Alice", "alice-pass-1");
  const rows = await db.all<any>("SELECT * FROM users");
  for (const r of rows) {
    assert.ok(r.password_hash.length > 40);
    assert.ok(r.password_salt.length > 10);
    assert.ok(!JSON.stringify(r).includes("alice-pass-1"));
    assert.ok(!JSON.stringify(r).includes(OWNER_PW));
  }
  assert.notEqual(rows[0].password_salt, rows[1].password_salt);
});

test("login: wrong password rejected, rate limit after repeated failures", async () => {
  const { hub } = await setupWithOwner();
  await hub.register("alice", "Alice", "alice-pass-1");
  for (let i = 0; i < 5; i++) await expectCode(hub.login("alice", "nope-nope"), "BAD_CREDENTIALS");
  await expectCode(hub.login("alice", "alice-pass-1"), "RATE_LIMITED");
});

test("ordinary accounts cannot use ANY owner operation", async () => {
  const { hub } = await setupWithOwner();
  const alice = await hub.register("alice", "Alice", "alice-pass-1");
  await hub.login("alice", "alice-pass-1");
  await expectCode(hub.listUsers(), "FORBIDDEN");
  await expectCode(hub.createUser({ username: "x1x", displayName: "X", password: "password1" }), "FORBIDDEN");
  await expectCode(hub.updateUser(alice.id, { displayName: "Hax" }), "FORBIDDEN");
  await expectCode(hub.setStatus(alice.id, "banned"), "FORBIDDEN");
  await expectCode(hub.deleteUser(alice.id, "alice"), "FORBIDDEN");
  await expectCode(hub.setMemberSince(alice.id, "2015-01-01"), "FORBIDDEN");
  await expectCode(hub.generateTestAccounts({ count: 1, prefix: "t", password: "password1" }), "FORBIDDEN");
  await expectCode(hub.deleteAllTestAccounts("DELETE TEST ACCOUNTS"), "FORBIDDEN");
  await expectCode(hub.listAudit(), "FORBIDDEN");
  await expectCode(hub.exportBackup(), "FORBIDDEN");
  await expectCode(hub.restoreBackup("{}", "RESTORE"), "FORBIDDEN");
  await expectCode(hub.setBranding({ name: "Hacked" }), "FORBIDDEN");
  await expectCode(hub.unlockAdmin("alice-pass-1"), "FORBIDDEN");
});

test("owner actions are locked after login until the password is re-entered, and re-lock after timeout", async () => {
  const { hub, clock } = await setupWithOwner();
  hub.logout();
  await hub.login("boss", OWNER_PW);
  await expectCode(hub.listUsers(), "ADMIN_LOCKED");
  await expectCode(hub.unlockAdmin("wrong-password"), "BAD_CREDENTIALS");
  await hub.unlockAdmin(OWNER_PW);
  assert.equal((await hub.listUsers()).length, 1);
  clock.t += 6 * 60 * 1000;
  await expectCode(hub.listUsers(), "ADMIN_LOCKED");
});

test("suspend / ban / restore control login; owner cannot be suspended, banned or deleted", async () => {
  const { hub } = await setupWithOwner();
  const alice = await hub.register("alice", "Alice", "alice-pass-1");
  await hub.setStatus(alice.id, "suspended");
  await expectCode(hub.login("alice", "alice-pass-1"), "ACCOUNT_SUSPENDED");
  await hub.setStatus(alice.id, "banned");
  await expectCode(hub.login("alice", "alice-pass-1"), "ACCOUNT_BANNED");
  await hub.setStatus(alice.id, "active");
  hub.logout();
  await hub.login("alice", "alice-pass-1");
  hub.logout();
  await hub.login("boss", OWNER_PW);
  await hub.unlockAdmin(OWNER_PW);
  const me = (await hub.currentUser())!;
  await expectCode(hub.setStatus(me.id, "banned"), "FORBIDDEN");
  await expectCode(hub.deleteUser(me.id, "boss"), "FORBIDDEN");
});

test("suspending an account kicks out an already-logged-in session", async () => {
  const { hub, db } = await setupWithOwner();
  const alice = await hub.register("alice", "Alice", "alice-pass-1");
  await hub.login("alice", "alice-pass-1");
  await db.run("UPDATE users SET status='suspended' WHERE id=?", [alice.id]);
  assert.equal(await hub.currentUser(), null);
});

test("delete requires typed confirmation; messages survive with author name", async () => {
  const { hub } = await setupWithOwner();
  const alice = await hub.register("alice", "Alice", "alice-pass-1");
  await hub.login("alice", "alice-pass-1");
  const ws = await hub.createWorkspace("Club");
  const ch = (await hub.listChannels(ws.id))[0];
  await hub.sendMessage(ch.id, "hello");
  hub.logout();
  await hub.login("boss", OWNER_PW);
  await hub.unlockAdmin(OWNER_PW);
  await expectCode(hub.deleteUser(alice.id, "wrong"), "CONFIRMATION_FAILED");
  await hub.deleteUser(alice.id, "alice");
  const msgs = await hub.listMessages(ch.id);
  assert.equal(msgs[0].authorName, "Alice");
  assert.equal(msgs[0].authorId, null);
});

test("Member Since: display date is editable, real created_at never changes, audit records old/new", async () => {
  const { hub, db, clock } = await setupWithOwner();
  const alice = await hub.register("alice", "Alice", "alice-pass-1");
  const before = (await db.all<any>("SELECT created_at FROM users WHERE id=?", [alice.id]))[0].created_at;
  clock.t += 86400_000;
  await hub.unlockAdmin(OWNER_PW); // a day later the admin lock has expired (correct)
  const u = await hub.setMemberSince(alice.id, "2019-05-20");
  assert.ok(u.memberSinceDisplay!.startsWith("2019-05-20"));
  assert.equal(u.createdAt, before);
  await hub.updateUser(alice.id, { displayName: "Alice2" });
  await hub.setStatus(alice.id, "suspended");
  await hub.setMemberSince(alice.id, null);
  const after = (await db.all<any>("SELECT created_at, member_since_display FROM users WHERE id=?", [alice.id]))[0];
  assert.equal(after.created_at, before);
  assert.equal(after.member_since_display, null);
  await expectCode(hub.setMemberSince(alice.id, "not-a-date"), "INVALID_INPUT");
  const log = await hub.listAudit();
  const e = log.find((x) => x.action === "user.set_member_since")!;
  assert.ok(e.detail.includes("2019-05-20"));
});

test("test-account generation: batches, unique names, flagged, capped, bulk delete needs confirmation", async () => {
  const { hub } = await setupWithOwner();
  const names = await hub.generateTestAccounts({ count: 5, prefix: "tester", password: "password-123" });
  assert.deepEqual(names, ["tester1", "tester2", "tester3", "tester4", "tester5"]);
  const more = await hub.generateTestAccounts({ count: 2, prefix: "tester", password: "password-123", memberSince: "2020-01-01" });
  assert.deepEqual(more, ["tester6", "tester7"]);
  const users = await hub.listUsers();
  assert.equal(users.filter((u) => u.isTest).length, 7);
  await expectCode(hub.generateTestAccounts({ count: 201, prefix: "x", password: "password-123" }), "INVALID_INPUT");
  await expectCode(hub.generateTestAccounts({ count: 0, prefix: "x", password: "password-123" }), "INVALID_INPUT");
  await expectCode(hub.deleteAllTestAccounts("yes"), "CONFIRMATION_FAILED");
  assert.equal(await hub.deleteAllTestAccounts("DELETE TEST ACCOUNTS"), 7);
  assert.equal((await hub.listUsers()).length, 1);
});

test("audit log records administrative actions", async () => {
  const { hub } = await setupWithOwner();
  const a = await hub.createUser({ username: "carol", displayName: "Carol", password: "password-123" });
  await hub.setStatus(a.id, "banned");
  await hub.setStatus(a.id, "active");
  const actions = (await hub.listAudit()).map((x) => x.action);
  for (const want of ["owner.setup", "user.create", "user.ban", "user.restore"]) assert.ok(actions.includes(want), want);
});

test("branding is configurable by the owner only and validated", async () => {
  const { hub } = await setupWithOwner();
  assert.equal((await hub.getBranding()).name, "OfflineHub");
  const b = await hub.setBranding({ name: "My Club", accent: "#ff8800" });
  assert.equal(b.name, "My Club");
  await expectCode(hub.setBranding({ accent: "red" }), "INVALID_INPUT");
  await expectCode(hub.setBranding({ logo: "javascript:alert(1)" }), "INVALID_INPUT");
});
