import { RoomGuest, type GuestLink } from "../src/room/guest.ts";
import { RoomHost, type HostConn } from "../src/room/host.ts";
import type { ClientMsg, JoinInfo, ServerMsg } from "../src/room/protocol.ts";

/** Test-only: connects a guest to a host in memory (no network), delivering messages synchronously. */
export interface Link {
  guest: RoomGuest;
  conn: HostConn;
  /** Send any raw (possibly malformed) message to the host as if the guest's phone sent it. */
  raw(m: unknown): void;
  closed: () => boolean;
}

export function connect(host: RoomHost, code: string, info: JoinInfo): Link {
  let isClosed = false;
  let guest!: RoomGuest;
  const conn: HostConn = {
    send: (m: ServerMsg) => { if (!isClosed) guest.handle(m); },
    close: () => {
      if (isClosed) return;
      isClosed = true;
      host.onDisconnect(conn);
      guest.onDisconnected();
    },
  };
  const link: GuestLink = {
    send: (m: ClientMsg) => { if (!isClosed) host.onMessage(conn, m); },
    close: () => conn.close(),
  };
  guest = new RoomGuest(link, code, info);
  return { guest, conn, raw: (m) => { if (!isClosed) host.onMessage(conn, m); }, closed: () => isClosed };
}

export const INFO = (name: string): JoinInfo => ({ displayName: name, avatarColor: "#3ba55d" });
