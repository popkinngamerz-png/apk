import { registerPlugin } from "@capacitor/core";
import type { NativeRoom } from "../room/nativeTypes.ts";

/** The Android plugin in plugins/offlinehub-room (Wi-Fi / hotspot rooms; no internet). */
export const nativeRoom = registerPlugin<NativeRoom>("OfflineRoom");
