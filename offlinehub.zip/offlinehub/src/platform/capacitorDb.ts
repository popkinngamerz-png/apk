import { Capacitor } from "@capacitor/core";
import { CapacitorSQLite, SQLiteConnection, type SQLiteDBConnection } from "@capacitor-community/sqlite";
import type { Db, SqlValue } from "../core/db.ts";

const DB_NAME = "offlinehub";

/** Persistent SQLite on the device (survives app restarts). Android only. */
export async function openDeviceDb(): Promise<Db> {
  if (Capacitor.getPlatform() === "web") {
    throw new Error("OfflineHub needs the Android app: the database plugin does not run in a normal browser.");
  }
  const sqlite = new SQLiteConnection(CapacitorSQLite);
  const consistency = await sqlite.checkConnectionsConsistency();
  const isConn = (await sqlite.isConnection(DB_NAME, false)).result;
  let conn: SQLiteDBConnection;
  if (consistency.result && isConn) conn = await sqlite.retrieveConnection(DB_NAME, false);
  else conn = await sqlite.createConnection(DB_NAME, false, "no-encryption", 1, false);
  await conn.open();

  let depth = 0;
  const db: Db = {
    async run(sql, params: SqlValue[] = []) {
      await conn.run(sql, params, false);
    },
    async all<T>(sql: string, params: SqlValue[] = []) {
      const r = await conn.query(sql, params);
      return (r.values ?? []) as T[];
    },
    async transaction<T>(fn: () => Promise<T>) {
      if (depth > 0) return fn();
      depth++;
      await conn.execute("BEGIN TRANSACTION;", false);
      try {
        const r = await fn();
        await conn.execute("COMMIT;", false);
        return r;
      } catch (e) {
        await conn.execute("ROLLBACK;", false).catch(() => undefined);
        throw e;
      } finally {
        depth--;
      }
    },
  };
  await conn.execute("PRAGMA foreign_keys = ON;", false).catch(() => undefined);
  return db;
}
