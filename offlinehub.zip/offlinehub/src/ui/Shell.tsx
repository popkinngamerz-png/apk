import { useCallback, useEffect, useRef, useState } from "react";
import type { Branding, Hub, PublicUser } from "../core/hub.ts";
import { Perm, has } from "../core/permissions.ts";
import { Avatar, Modal, errMsg, fmtDateTime, useAction } from "./common.tsx";
import { OwnerDashboard } from "./OwnerDashboard.tsx";
import { ProfileModal } from "./Profile.tsx";
import { RoomScreen } from "./RoomScreen.tsx";
import { WorkspaceSettings } from "./WorkspaceSettings.tsx";

interface Props {
  hub: Hub;
  brand: Branding;
  user: PublicUser;
  onUser: (u: PublicUser) => void;
  onBrand: () => Promise<void>;
  onSignOut: () => void;
  onRestored: () => void;
}

type Ws = { id: string; name: string };
type Ch = { id: string; name: string };
type Msg = { id: string; authorId: string | null; authorName: string; body: string; createdAt: string };
type ModalKind = null | "profile" | "owner" | "wsSettings" | "join" | "newWs" | "newChannel" | "rooms";

export function Shell({ hub, brand, user, onUser, onBrand, onSignOut, onRestored }: Props) {
  const [workspaces, setWorkspaces] = useState<Ws[]>([]);
  const [wsId, setWsId] = useState<string | null>(null);
  const [channels, setChannels] = useState<Ch[]>([]);
  const [chId, setChId] = useState<string | null>(null);
  const [msgs, setMsgs] = useState<Msg[]>([]);
  const [open, setOpen] = useState(false);
  const [modal, setModal] = useState<ModalKind>(null);
  const [text, setText] = useState("");
  const [canManageCh, setCanManageCh] = useState(false);
  const [canSend, setCanSend] = useState(true);
  const [canModerate, setCanModerate] = useState(false);
  const a = useAction();
  const endRef = useRef<HTMLDivElement>(null);

  const loadWorkspaces = useCallback(async (select?: string) => {
    const list = await hub.myWorkspaces();
    setWorkspaces(list);
    setWsId((cur) => select ?? (cur && list.some((w) => w.id === cur) ? cur : list[0]?.id ?? null));
  }, [hub]);

  useEffect(() => { void a.run(() => loadWorkspaces()); }, [loadWorkspaces]);

  useEffect(() => {
    if (!wsId) { setChannels([]); setChId(null); return; }
    void a.run(async () => {
      const list = await hub.listChannels(wsId);
      setChannels(list);
      setChId((cur) => (cur && list.some((c) => c.id === cur) ? cur : list[0]?.id ?? null));
      // permission hints for the UI only; the Hub re-checks every action
      const roles = await hub.listRoles(wsId);
      const mine = (await hub.listMembers(wsId)).find((m) => m.userId === user.id);
      const role = roles.find((r) => r.id === mine?.roleId);
      const full = user.isOwner;
      const mask = role?.permissions ?? 0;
      setCanManageCh(full || has(mask, Perm.MANAGE_CHANNELS));
      setCanSend(full || has(mask, Perm.SEND));
      setCanModerate(full || has(mask, Perm.MANAGE_MESSAGES));
    });
  }, [wsId, hub, user.id, user.isOwner]);

  const loadMsgs = useCallback(async () => {
    if (!chId) { setMsgs([]); return; }
    setMsgs(await hub.listMessages(chId));
  }, [hub, chId]);

  useEffect(() => { void a.run(loadMsgs); }, [loadMsgs]);
  useEffect(() => { endRef.current?.scrollIntoView({ block: "end" }); }, [msgs]);

  async function send() {
    if (!chId || !text.trim()) return;
    const ok = await a.run(async () => { await hub.sendMessage(chId, text); await loadMsgs(); return true; });
    if (ok) setText("");
  }

  const ws = workspaces.find((w) => w.id === wsId);
  const ch = channels.find((c) => c.id === chId);

  return (
    <div className="shell">
      <div className={`scrim ${open ? "open" : ""}`} onClick={() => setOpen(false)} />
      <aside className={`side ${open ? "open" : ""}`}>
        <div className="row" style={{ padding: 12 }}>
          <strong>{brand.name}</strong>
        </div>
        <h4>Workspaces</h4>
        {workspaces.map((w) => (
          <div key={w.id} className={`item ${w.id === wsId ? "active" : ""}`} onClick={() => setWsId(w.id)}>{w.name}</div>
        ))}
        <div className="row" style={{ padding: "4px 6px" }}>
          <button className="ghost" onClick={() => { setModal("newWs"); setOpen(false); }}>＋ Create</button>
          <button className="ghost" onClick={() => { setModal("join"); setOpen(false); }}>Join</button>
        </div>
        {ws && (<>
          <h4>Text channels</h4>
          {channels.map((c) => (
            <div key={c.id} className={`item ${c.id === chId ? "active" : ""}`} onClick={() => { setChId(c.id); setOpen(false); }}># {c.name}</div>
          ))}
          {canManageCh && <button className="ghost" onClick={() => { setModal("newChannel"); setOpen(false); }}>＋ New channel</button>}
          <button className="ghost" onClick={() => { setModal("wsSettings"); setOpen(false); }}>⚙ Workspace settings</button>
        </>)}
        <div style={{ flex: 1 }} />
        <div style={{ padding: 8, borderTop: "1px solid var(--border)" }} className="stack">
          <div className="row" onClick={() => { setModal("profile"); setOpen(false); }} style={{ cursor: "pointer" }}>
            <Avatar name={user.displayName} color={user.avatarColor} />
            <div style={{ minWidth: 0 }}><div>{user.displayName}</div><div className="note">@{user.username}{user.isOwner ? " · Owner" : ""}</div></div>
          </div>
          <button style={{ width: "100%" }} onClick={() => { setModal("rooms"); setOpen(false); }}>📡 Rooms (Wi-Fi)</button>
          {user.isOwner && <button style={{ width: "100%" }} onClick={() => { setModal("owner"); setOpen(false); }}>🛡 Owner dashboard</button>}
          <button style={{ width: "100%" }} onClick={onSignOut}>Log out</button>
        </div>
      </aside>

      <main className="main">
        <div className="top">
          <button className="menu-btn ghost" onClick={() => setOpen(true)}>☰</button>
          <div className="title">{ws ? `${ws.name}${ch ? " · # " + ch.name : ""}` : brand.name}</div>
        </div>
        {a.error && <div className="err" style={{ padding: "0 12px" }}>{a.error}</div>}
        {!ws ? (
          <div className="msgs note">No workspace yet. Open the menu (☰) and tap “＋ Create” to make one, or “Join” to enter an existing one on this device.</div>
        ) : (
          <>
            <div className="msgs">
              {msgs.length === 0 && <div className="note">No messages yet. Say something!</div>}
              {msgs.map((m) => (
                <div className="msg" key={m.id}>
                  <Avatar name={m.authorName} color="#5865f2" />
                  <div style={{ minWidth: 0, flex: 1 }}>
                    <div className="meta"><strong style={{ color: "var(--text)" }}>{m.authorName}</strong> · {fmtDateTime(m.createdAt)}
                      {(m.authorId === user.id || canModerate) && <button className="ghost" style={{ padding: "0 6px", fontSize: 12 }} onClick={() => a.run(async () => { await hub.deleteMessage(m.id); await loadMsgs(); })}>delete</button>}
                    </div>
                    <div className="body">{m.body}</div>
                  </div>
                </div>
              ))}
              <div ref={endRef} />
            </div>
            <div className="composer">
              <textarea value={text} placeholder={canSend ? `Message #${ch?.name ?? ""}` : "You cannot send messages here"} disabled={!canSend} onChange={(e) => setText(e.target.value)} />
              <button className="primary fit" disabled={!canSend || a.busy} onClick={send}>Send</button>
            </div>
          </>
        )}
      </main>

      {modal === "rooms" && <RoomScreen user={user} onClose={() => setModal(null)} />}
      {modal === "profile" && <ProfileModal hub={hub} user={user} onClose={() => setModal(null)} onUser={onUser} />}
      {modal === "owner" && <OwnerDashboard hub={hub} brand={brand} onClose={() => setModal(null)} onBrand={onBrand} onRestored={onRestored} />}
      {modal === "wsSettings" && ws && <WorkspaceSettings hub={hub} ws={ws} user={user} onClose={() => setModal(null)} onDeleted={() => { setModal(null); void loadWorkspaces(); }} />}
      {modal === "newWs" && <NameModal title="Create workspace" label="Workspace name" cta="Create" onClose={() => setModal(null)} onSubmit={async (n) => { const w = await hub.createWorkspace(n); await loadWorkspaces(w.id); }} />}
      {modal === "newChannel" && ws && <NameModal title="New text channel" label="Channel name" cta="Create" onClose={() => setModal(null)} onSubmit={async (n) => { const c = await hub.createChannel(ws.id, n); const list = await hub.listChannels(ws.id); setChannels(list); setChId(c.id); }} />}
      {modal === "join" && <JoinModal hub={hub} onClose={() => setModal(null)} onJoined={(id) => { setModal(null); void loadWorkspaces(id); }} />}
    </div>
  );
}

function NameModal(props: { title: string; label: string; cta: string; onClose: () => void; onSubmit: (name: string) => Promise<void> }) {
  const [name, setName] = useState("");
  const a = useAction();
  return (
    <Modal title={props.title} onClose={props.onClose}>
      <label>{props.label}</label>
      <input value={name} onChange={(e) => setName(e.target.value)} autoFocus />
      {a.error && <div className="err">{a.error}</div>}
      <button className="primary" style={{ width: "100%", marginTop: 12 }} disabled={a.busy} onClick={async () => { const ok = await a.run(async () => { await props.onSubmit(name); return true; }); if (ok) props.onClose(); }}>{props.cta}</button>
    </Modal>
  );
}

function JoinModal({ hub, onClose, onJoined }: { hub: Hub; onClose: () => void; onJoined: (id: string) => void }) {
  const [list, setList] = useState<Ws[] | null>(null);
  const [error, setError] = useState("");
  useEffect(() => { hub.joinableWorkspaces().then(setList, (e) => setError(errMsg(e))); }, [hub]);
  return (
    <Modal title="Join a workspace" onClose={onClose}>
      {error && <div className="err">{error}</div>}
      {list && list.length === 0 && <div className="note">There are no other workspaces on this device.</div>}
      {list?.map((w) => (
        <div className="table-row" key={w.id}>
          <div className="grow">{w.name}</div>
          <button className="primary fit" onClick={async () => { try { await hub.joinWorkspace(w.id); onJoined(w.id); } catch (e) { setError(errMsg(e)); } }}>Join</button>
        </div>
      ))}
    </Modal>
  );
}
