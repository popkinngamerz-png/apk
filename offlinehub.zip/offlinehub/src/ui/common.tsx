import { useState, type ReactNode } from "react";
import type { Hub } from "../core/hub.ts";

export function errMsg(e: unknown): string {
  return e instanceof Error ? e.message : String(e);
}

export function fmtDate(iso: string): string {
  const d = new Date(iso);
  return Number.isNaN(d.getTime()) ? iso : d.toLocaleDateString(undefined, { year: "numeric", month: "short", day: "numeric" });
}
export function fmtDateTime(iso: string): string {
  const d = new Date(iso);
  return Number.isNaN(d.getTime()) ? iso : d.toLocaleString();
}

export function Modal(props: { title: string; onClose: () => void; children: ReactNode }) {
  return (
    <div className="modal-bg" onClick={props.onClose}>
      <div className="modal" onClick={(e) => e.stopPropagation()}>
        <div className="row" style={{ marginBottom: 8 }}>
          <h3>{props.title}</h3>
          <button className="ghost fit" onClick={props.onClose}>✕</button>
        </div>
        {props.children}
      </div>
    </div>
  );
}

export function Avatar(props: { name: string; color: string }) {
  return <div className="avatar" style={{ background: props.color }}>{(props.name[0] ?? "?").toUpperCase()}</div>;
}

/** Runs an async action, shows its error text, and reports busy state. */
export function useAction() {
  const [error, setError] = useState("");
  const [busy, setBusy] = useState(false);
  async function run<T>(fn: () => Promise<T>): Promise<T | undefined> {
    setBusy(true);
    setError("");
    try {
      return await fn();
    } catch (e) {
      setError(errMsg(e));
      return undefined;
    } finally {
      setBusy(false);
    }
  }
  return { error, busy, run, setError };
}

export function randomPassword(len = 12): string {
  const chars = "ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnopqrstuvwxyz23456789";
  const b = new Uint8Array(len);
  crypto.getRandomValues(b);
  return Array.from(b, (x) => chars[x % chars.length]).join("");
}

export interface HubProps {
  hub: Hub;
}
