import { useState } from "react";
import type { Hub, PublicUser } from "../core/hub.ts";
import { displayedMemberSince } from "../core/hub.ts";
import { Avatar, Modal, fmtDate, useAction } from "./common.tsx";

const COLORS = ["#5865f2", "#3ba55d", "#ed4245", "#faa61a", "#eb459e", "#1abc9c", "#9b59b6"];

export function ProfileModal(props: { hub: Hub; user: PublicUser; onClose: () => void; onUser: (u: PublicUser) => void }) {
  const { hub, user } = props;
  const [display, setDisplay] = useState(user.displayName);
  const [bio, setBio] = useState(user.bio);
  const [color, setColor] = useState(user.avatarColor);
  const [oldPw, setOldPw] = useState("");
  const [newPw, setNewPw] = useState("");
  const [msg, setMsg] = useState("");
  const a = useAction();
  const b = useAction();

  return (
    <Modal title="My profile" onClose={props.onClose}>
      <div className="row"><Avatar name={display} color={color} /><div><div>@{user.username}</div><div className="note">Member since {fmtDate(displayedMemberSince(user))}</div></div></div>
      <label>Display name</label>
      <input value={display} onChange={(e) => setDisplay(e.target.value)} />
      <label>About me</label>
      <textarea rows={3} value={bio} onChange={(e) => setBio(e.target.value)} />
      <label>Avatar color</label>
      <div className="row">{COLORS.map((c) => <button key={c} className="fit" style={{ background: c, width: 34, height: 34, padding: 0, outline: c === color ? "2px solid #fff" : "none" }} onClick={() => setColor(c)} />)}</div>
      {a.error && <div className="err">{a.error}</div>}
      <button className="primary" style={{ width: "100%", marginTop: 12 }} disabled={a.busy} onClick={async () => { const u = await a.run(() => hub.updateProfile({ displayName: display, bio, avatarColor: color })); if (u) { props.onUser(u); props.onClose(); } }}>Save profile</button>
      <h3 style={{ marginTop: 20 }}>Change password</h3>
      <input type="password" placeholder="Current password" value={oldPw} onChange={(e) => setOldPw(e.target.value)} />
      <input type="password" placeholder="New password" style={{ marginTop: 8 }} value={newPw} onChange={(e) => setNewPw(e.target.value)} />
      {b.error && <div className="err">{b.error}</div>}
      {msg && <div className="note">{msg}</div>}
      <button style={{ width: "100%", marginTop: 8 }} disabled={b.busy} onClick={async () => { const ok = await b.run(async () => { await hub.changePassword(oldPw, newPw); return true; }); if (ok) { setMsg("Password changed."); setOldPw(""); setNewPw(""); } }}>Change password</button>
    </Modal>
  );
}
