import { useEffect, useRef, useState, type ReactNode } from "react";
import type { PublicUser } from "../core/hub.ts";
import { nativeRoom } from "../platform/roomNative.ts";
import { normalizeCodeInput } from "../room/code.ts";
import { joinRoomSession, type GuestSession } from "../room/guestSession.ts";
import { startHostSession, type HostSession } from "../room/hostSession.ts";
import type { ChatMessage, Peer, RejectReason } from "../room/protocol.ts";
import { Avatar, errMsg, fmtDateTime } from "./common.tsx";

type Session = { kind: "host"; s: HostSession } | { kind: "guest"; s: GuestSession };

const COLOR_OK = /^#[0-9a-fA-F]{6}$/;
const IPV4 = /^[0-9]{1,3}(\.[0-9]{1,3}){3}$/;

function friendly(e: unknown): string {
  const m = errMsg(e);
  if (/not implemented|unimplemented/i.test(m)) return "Rooms work only inside the Android app.";
  return m;
}

async function endSession(s: Session | null): Promise<void> {
  if (!s) return;
  try {
    if (s.kind === "host") await s.s.stop();
    else await s.s.leave();
  } catch {
    // already closed
  }
}

const REJECTED_TEXT: Record<RejectReason, string> = {
  bad_code: "Wrong code. Check the 6 digits and try again.",
  full: "This room is full.",
  locked: "Too many wrong codes. Wait 30 seconds and try again.",
  bad_request: "The host could not accept your profile.",
};

export function RoomScreen({ user, onClose }: { user: PublicUser; onClose: () => void }) {
  const [view, setView] = useState<"menu" | "join">("menu");
  const [session, setSession] = useState<Session | null>(null);
  const [busy, setBusy] = useState("");
  const [error, setError] = useState("");
  const [code, setCode] = useState("");
  const [ip, setIp] = useState("");
  const [showIp, setShowIp] = useState(false);
  const live = useRef<Session | null>(null);
  live.current = session;

  // Leaving the screen (or logging out) always closes the room / connection.
  useEffect(() => () => { void endSession(live.current); }, []);

  const me = {
    displayName: user.displayName.trim().slice(0, 40) || user.username,
    avatarColor: COLOR_OK.test(user.avatarColor) ? user.avatarColor : "#5865f2",
  };

  async function hostRoom() {
    setBusy("Opening room…");
    setError("");
    try {
      const s = await startHostSession(nativeRoom, { hostName: me.displayName, hostColor: me.avatarColor });
      setSession({ kind: "host", s });
    } catch (e) {
      setError(friendly(e));
    } finally {
      setBusy("");
    }
  }

  async function joinRoom() {
    setError("");
    if (code.length !== 6) return setError("Enter the 6-digit room code.");
    const typedIp = showIp ? ip.trim() : "";
    if (typedIp && !IPV4.test(typedIp)) return setError("The host address looks wrong. Example: 192.168.43.1");
    setBusy(typedIp ? "Connecting…" : "Searching this Wi-Fi/hotspot…");
    try {
      const s = await joinRoomSession(nativeRoom, { code, info: me, ip: typedIp || undefined });
      setSession({ kind: "guest", s });
    } catch (e) {
      setError(friendly(e));
    } finally {
      setBusy("");
    }
  }

  async function backToMenu() {
    const s = session;
    setSession(null);
    setView("menu");
    setError("");
    await endSession(s);
  }

  async function closeScreen() {
    await backToMenu();
    onClose();
  }

  let body: ReactNode;
  if (session?.kind === "host") body = <HostRoom s={session.s} onLeave={backToMenu} />;
  else if (session?.kind === "guest") body = <GuestRoom s={session.s} onLeave={backToMenu} />;
  else if (view === "join") {
    body = (
      <div className="room-body stack">
        <h3>Join a room</h3>
        <div className="note">Ask the host for the 6-digit code. You must be on the same Wi-Fi, or connected to the host's hotspot.</div>
        <input
          className="code-input"
          inputMode="numeric"
          placeholder="••••••"
          value={code}
          maxLength={7}
          autoFocus
          onChange={(e) => setCode(normalizeCodeInput(e.target.value))}
        />
        <button className="ghost" onClick={() => setShowIp(!showIp)}>{showIp ? "Hide" : "Can't find the room? Enter the host's address"}</button>
        {showIp && (
          <div>
            <label>Host address (shown on the host's screen)</label>
            <input inputMode="decimal" placeholder="192.168.43.1" value={ip} onChange={(e) => setIp(e.target.value)} />
          </div>
        )}
        {error && <div className="err">{error}</div>}
        <button className="primary" style={{ width: "100%" }} disabled={!!busy} onClick={joinRoom}>{busy || "Join"}</button>
        <button style={{ width: "100%" }} disabled={!!busy} onClick={() => { setView("menu"); setError(""); }}>Back</button>
      </div>
    );
  } else {
    body = (
      <div className="room-body stack">
        <h3>Rooms</h3>
        <div className="note">Private rooms for up to 4 people on the same Wi-Fi or hotspot. No internet needed.</div>
        {error && <div className="err">{error}</div>}
        <button className="primary" style={{ width: "100%" }} disabled={!!busy} onClick={hostRoom}>{busy || "Host a room"}</button>
        <button style={{ width: "100%" }} disabled={!!busy} onClick={() => { setView("join"); setError(""); }}>Join a room</button>
      </div>
    );
  }

  return (
    <div className="room-screen">
      <div className="top">
        <button className="ghost fit" onClick={closeScreen}>✕</button>
        <div className="title">Rooms</div>
      </div>
      {body}
    </div>
  );
}

function HostRoom({ s, onLeave }: { s: HostSession; onLeave: () => void }) {
  const [members, setMembers] = useState<Peer[]>(s.host.members());
  const [guests, setGuests] = useState(s.host.guestCount);
  const [msgs, setMsgs] = useState<ChatMessage[]>([]);
  useEffect(
    () =>
      s.host.subscribe((e) => {
        if (e.t === "members") {
          setMembers(e.members);
          setGuests(e.guests);
        } else {
          setMsgs((m) => [...m, e.msg]);
        }
      }),
    [s],
  );
  const code = `${s.code.slice(0, 3)} ${s.code.slice(3)}`;
  return (
    <RoomChat
      header={
        <div style={{ padding: "8px 12px", borderBottom: "1px solid var(--border)" }}>
          <div className="note" style={{ textAlign: "center" }}>Room code — tell your friends</div>
          <div className="room-code">{code}</div>
          <div className="note" style={{ textAlign: "center" }}>
            {guests}/{s.host.maxGuests} joined
            {s.addresses.length > 0 && <> · If the code search fails, others can join using the address {s.addresses.join(" or ")}</>}
          </div>
        </div>
      }
      members={members}
      messages={msgs}
      myId={members[0]?.id ?? ""}
      onSend={(t) => s.host.sendHostChat(t)}
      onLeave={onLeave}
      leaveLabel="Close room"
    />
  );
}

function GuestRoom({ s, onLeave }: { s: GuestSession; onLeave: () => void }) {
  const [snap, setSnap] = useState(s.guest.snapshot);
  useEffect(() => {
    setSnap(s.guest.snapshot);
    return s.guest.subscribe(setSnap);
  }, [s]);

  if (snap.state === "rejected") {
    return (
      <div className="room-body stack">
        <div className="err">{snap.rejectReason ? REJECTED_TEXT[snap.rejectReason] : "Could not join."}</div>
        <button className="primary" style={{ width: "100%" }} onClick={onLeave}>Back</button>
      </div>
    );
  }
  if (snap.state === "idle" || snap.state === "joining") {
    return <div className="room-body note">Joining…</div>;
  }
  return (
    <RoomChat
      header={
        <div className="note" style={{ padding: "8px 12px", borderBottom: "1px solid var(--border)", textAlign: "center" }}>
          {snap.guests}/{snap.max} joined
        </div>
      }
      members={snap.members}
      messages={snap.messages}
      myId={snap.youId ?? ""}
      ended={snap.state === "closed" ? "The room was closed or the connection was lost." : undefined}
      onSend={(t) => s.guest.sendChat(t)}
      onLeave={onLeave}
      leaveLabel="Leave room"
    />
  );
}

function RoomChat(props: {
  header: ReactNode;
  members: Peer[];
  messages: ChatMessage[];
  myId: string;
  ended?: string;
  onSend: (text: string) => boolean;
  onLeave: () => void;
  leaveLabel: string;
}) {
  const [text, setText] = useState("");
  const endRef = useRef<HTMLDivElement>(null);
  useEffect(() => { endRef.current?.scrollIntoView?.({ block: "end" }); }, [props.messages.length]);
  const colorOf = (id: string) => props.members.find((m) => m.id === id)?.avatarColor ?? "#5865f2";

  function send() {
    if (props.onSend(text)) setText("");
  }

  return (
    <>
      {props.header}
      <div className="members">
        {props.members.map((m) => (
          <div className="chip" key={m.id}>
            <Avatar name={m.displayName} color={m.avatarColor} />
            <span>{m.displayName}{m.isHost ? " 👑" : ""}{m.id === props.myId ? " (you)" : ""}</span>
          </div>
        ))}
      </div>
      <div className="msgs">
        {props.messages.length === 0 && <div className="note">No messages yet. Say something!</div>}
        {props.messages.map((m) => (
          <div className="msg" key={m.id}>
            <Avatar name={m.fromName} color={colorOf(m.fromId)} />
            <div style={{ minWidth: 0, flex: 1 }}>
              <div className="meta"><strong style={{ color: "var(--text)" }}>{m.fromName}</strong> · {fmtDateTime(m.at)}</div>
              <div className="body">{m.body}</div>
            </div>
          </div>
        ))}
        <div ref={endRef} />
      </div>
      {props.ended && <div className="err" style={{ padding: "0 12px" }}>{props.ended}</div>}
      <div className="composer">
        <textarea value={text} placeholder="Message" disabled={!!props.ended} maxLength={2000} onChange={(e) => setText(e.target.value)} />
        <button className="primary fit" disabled={!!props.ended} onClick={send}>Send</button>
      </div>
      <div style={{ padding: "0 10px 10px" }}>
        <button style={{ width: "100%" }} onClick={props.onLeave}>{props.ended ? "Back" : props.leaveLabel}</button>
      </div>
    </>
  );
}
