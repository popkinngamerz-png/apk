import { useCallback, useEffect, useState } from "react";
import type { Branding, Hub, PublicUser } from "./core/hub.ts";
import { DEFAULT_BRANDING } from "./branding.ts";
import { useAction } from "./ui/common.tsx";
import { Shell } from "./ui/Shell.tsx";

type Screen = "loading" | "setup" | "auth" | "app";

export function App({ hub }: { hub: Hub }) {
  const [screen, setScreen] = useState<Screen>("loading");
  const [user, setUser] = useState<PublicUser | null>(null);
  const [brand, setBrand] = useState<Branding>(DEFAULT_BRANDING);

  const refreshBrand = useCallback(async () => {
    const b = await hub.getBranding();
    setBrand(b);
    document.documentElement.style.setProperty("--accent", b.accent);
    document.title = b.name;
  }, [hub]);

  const start = useCallback(async () => {
    await refreshBrand();
    setScreen((await hub.isFirstRun()) ? "setup" : "auth");
  }, [hub, refreshBrand]);

  useEffect(() => {
    void start();
  }, [start]);

  function signedIn(u: PublicUser) {
    setUser(u);
    setScreen("app");
  }
  function signOut() {
    hub.logout();
    setUser(null);
    setScreen("auth");
  }

  if (screen === "loading") return <div className="center">Loading…</div>;
  if (screen === "setup") return <Setup hub={hub} brand={brand} onDone={signedIn} />;
  if (screen === "auth") return <Auth hub={hub} brand={brand} onDone={signedIn} />;
  return <Shell hub={hub} brand={brand} user={user!} onUser={setUser} onBrand={refreshBrand} onSignOut={signOut} onRestored={() => { setUser(null); void start(); }} />;
}

function BrandHeader({ brand }: { brand: Branding }) {
  return (
    <div style={{ textAlign: "center", marginBottom: 12 }}>
      {brand.logo ? <img src={brand.logo} alt="" style={{ width: 64, height: 64, borderRadius: 14, objectFit: "cover" }} /> : null}
      <h1>{brand.name}</h1>
      <div className="note">{brand.tagline}</div>
    </div>
  );
}

function Setup({ hub, brand, onDone }: { hub: Hub; brand: Branding; onDone: (u: PublicUser) => void }) {
  const [username, setUsername] = useState("");
  const [display, setDisplay] = useState("");
  const [pw, setPw] = useState("");
  const [pw2, setPw2] = useState("");
  const a = useAction();
  async function submit() {
    if (pw !== pw2) return a.setError("Passwords do not match");
    const u = await a.run(() => hub.setupOwner(username, display || username, pw));
    if (u) onDone(u);
  }
  return (
    <div className="center">
      <div className="card">
        <BrandHeader brand={brand} />
        <h3>First-time setup</h3>
        <div className="note">Create the Owner account. There is no default password. If you forget this password it cannot be recovered, so write it down.</div>
        <label>Owner username</label>
        <input value={username} onChange={(e) => setUsername(e.target.value)} autoCapitalize="none" />
        <label>Display name</label>
        <input value={display} onChange={(e) => setDisplay(e.target.value)} />
        <label>Password (10+ characters)</label>
        <input type="password" value={pw} onChange={(e) => setPw(e.target.value)} />
        <label>Repeat password</label>
        <input type="password" value={pw2} onChange={(e) => setPw2(e.target.value)} />
        {a.error && <div className="err">{a.error}</div>}
        <button className="primary" style={{ width: "100%", marginTop: 12 }} disabled={a.busy} onClick={submit}>{a.busy ? "Creating…" : "Create Owner account"}</button>
      </div>
    </div>
  );
}

function Auth({ hub, brand, onDone }: { hub: Hub; brand: Branding; onDone: (u: PublicUser) => void }) {
  const [mode, setMode] = useState<"login" | "register">("login");
  const [username, setUsername] = useState("");
  const [display, setDisplay] = useState("");
  const [pw, setPw] = useState("");
  const a = useAction();
  async function submit() {
    const u = await a.run(async () => {
      if (mode === "register") {
        await hub.register(username, display || username, pw);
      }
      return hub.login(username, pw);
    });
    if (u) onDone(u);
  }
  return (
    <div className="center">
      <div className="card">
        <BrandHeader brand={brand} />
        <div className="note">Accounts are local to this device. They are not Discord accounts.</div>
        <label>Username</label>
        <input value={username} onChange={(e) => setUsername(e.target.value)} autoCapitalize="none" />
        {mode === "register" && (<><label>Display name</label><input value={display} onChange={(e) => setDisplay(e.target.value)} /></>)}
        <label>Password</label>
        <input type="password" value={pw} onChange={(e) => setPw(e.target.value)} onKeyDown={(e) => e.key === "Enter" && void submit()} />
        {a.error && <div className="err">{a.error}</div>}
        <button className="primary" style={{ width: "100%", marginTop: 12 }} disabled={a.busy} onClick={submit}>{a.busy ? "Please wait…" : mode === "login" ? "Log in" : "Create account"}</button>
        <button className="ghost" style={{ width: "100%", marginTop: 6 }} onClick={() => { setMode(mode === "login" ? "register" : "login"); a.setError(""); }}>
          {mode === "login" ? "Create a new local account" : "I already have an account"}
        </button>
      </div>
    </div>
  );
}
