export type SqlValue = string | number | null;
export type Row = Record<string, any>;

/** Minimal async database interface. Implemented by Capacitor SQLite (app) and node:sqlite (tests). */
export interface Db {
  run(sql: string, params?: SqlValue[]): Promise<void>;
  all<T = Row>(sql: string, params?: SqlValue[]): Promise<T[]>;
  /** Runs fn atomically. Nested calls join the outer transaction. */
  transaction<T>(fn: () => Promise<T>): Promise<T>;
}

export class AppError extends Error {
  code: string;
  constructor(code: string, message: string) {
    super(message);
    this.code = code;
  }
}
