import type { Db } from "./db.ts";

export interface Migration {
  version: number;
  statements: string[];
}

export const MIGRATIONS: Migration[] = [
  {
    version: 1,
    statements: [
      `CREATE TABLE users (
        id TEXT PRIMARY KEY,
        username TEXT NOT NULL UNIQUE COLLATE NOCASE,
        display_name TEXT NOT NULL,
        password_hash TEXT NOT NULL,
        password_salt TEXT NOT NULL,
        iterations INTEGER NOT NULL,
        status TEXT NOT NULL DEFAULT 'active' CHECK (status IN ('active','suspended','banned')),
        is_owner INTEGER NOT NULL DEFAULT 0,
        is_test INTEGER NOT NULL DEFAULT 0,
        created_at TEXT NOT NULL,
        member_since_display TEXT,
        bio TEXT NOT NULL DEFAULT '',
        avatar_color TEXT NOT NULL DEFAULT '#5865f2'
      )`,
      `CREATE UNIQUE INDEX one_owner ON users(is_owner) WHERE is_owner = 1`,
      `CREATE TABLE workspaces (
        id TEXT PRIMARY KEY,
        name TEXT NOT NULL,
        owner_id TEXT NOT NULL,
        created_at TEXT NOT NULL
      )`,
      `CREATE TABLE roles (
        id TEXT PRIMARY KEY,
        workspace_id TEXT NOT NULL,
        name TEXT NOT NULL,
        permissions INTEGER NOT NULL,
        is_default INTEGER NOT NULL DEFAULT 0,
        created_at TEXT NOT NULL
      )`,
      `CREATE TABLE members (
        workspace_id TEXT NOT NULL,
        user_id TEXT NOT NULL,
        role_id TEXT NOT NULL,
        joined_at TEXT NOT NULL,
        PRIMARY KEY (workspace_id, user_id)
      )`,
      `CREATE TABLE channels (
        id TEXT PRIMARY KEY,
        workspace_id TEXT NOT NULL,
        name TEXT NOT NULL,
        created_at TEXT NOT NULL
      )`,
      `CREATE TABLE messages (
        seq INTEGER PRIMARY KEY AUTOINCREMENT,
        id TEXT NOT NULL UNIQUE,
        channel_id TEXT NOT NULL,
        author_id TEXT,
        author_name TEXT NOT NULL,
        body TEXT NOT NULL,
        created_at TEXT NOT NULL
      )`,
      `CREATE INDEX idx_messages_channel ON messages(channel_id, seq)`,
      `CREATE TABLE audit_log (
        seq INTEGER PRIMARY KEY AUTOINCREMENT,
        actor_id TEXT,
        actor_name TEXT NOT NULL,
        action TEXT NOT NULL,
        target TEXT NOT NULL DEFAULT '',
        detail TEXT NOT NULL DEFAULT '',
        created_at TEXT NOT NULL
      )`,
      `CREATE TABLE settings (key TEXT PRIMARY KEY, value TEXT NOT NULL)`,
    ],
  },
];

export async function migrate(db: Db, now: () => string): Promise<number> {
  await db.run(`CREATE TABLE IF NOT EXISTS schema_migrations (version INTEGER PRIMARY KEY, applied_at TEXT NOT NULL)`);
  const rows = await db.all<{ v: number | null }>(`SELECT MAX(version) AS v FROM schema_migrations`);
  const current = rows[0]?.v ?? 0;
  for (const m of MIGRATIONS) {
    if (m.version <= current) continue;
    await db.transaction(async () => {
      for (const s of m.statements) await db.run(s);
      await db.run(`INSERT INTO schema_migrations (version, applied_at) VALUES (?, ?)`, [m.version, now()]);
    });
  }
  return MIGRATIONS[MIGRATIONS.length - 1].version;
}
