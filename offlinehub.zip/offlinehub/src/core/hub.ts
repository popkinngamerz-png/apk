import { AppError, type Db, type Row, type SqlValue } from "./db.ts";
import { hashPassword, newId, verifyPassword, DEFAULT_ITERATIONS } from "./crypto.ts";
import { migrate } from "./migrations.ts";
import { ALL_PERMS, Perm, effective, has, isSubset } from "./permissions.ts";
import { BACKUP_FORMAT, BACKUP_VERSION, TABLES, TABLE_ORDER, type TableName } from "./backupFormat.ts";

export type Status = "active" | "suspended" | "banned";

export interface PublicUser {
  id: string;
  username: string;
  displayName: string;
  status: Status;
  isOwner: boolean;
  isTest: boolean;
  /** TRUE creation time. Immutable through the app. Shown only in the Owner dashboard. */
  createdAt: string;
  /** Owner-editable cosmetic date. null = show createdAt. */
  memberSinceDisplay: string | null;
  bio: string;
  avatarColor: string;
}

export interface Branding {
  name: string;
  tagline: string;
  accent: string;
  logo: string | null;
}

export const DEFAULT_BRANDING: Branding = { name: "OfflineHub", tagline: "Your offline community", accent: "#5865f2", logo: null };

export interface HubOptions {
  db: Db;
  now?: () => Date;
  iterations?: number;
}

const ADMIN_UNLOCK_MS = 5 * 60 * 1000;
const MAX_TEST_BATCH = 200;
const USERNAME_RE = /^[a-z0-9_.-]{3,24}$/i;

function err(code: string, message: string): never {
  throw new AppError(code, message);
}

export function displayedMemberSince(u: Pick<PublicUser, "memberSinceDisplay" | "createdAt">): string {
  return u.memberSinceDisplay ?? u.createdAt;
}

export class Hub {
  private db: Db;
  private nowFn: () => Date;
  private iterations: number;
  private sessionUserId: string | null = null;
  private adminUntil = 0;
  private fails = new Map<string, { count: number; until: number }>();

  constructor(opts: HubOptions) {
    this.db = opts.db;
    this.nowFn = opts.now ?? (() => new Date());
    this.iterations = opts.iterations ?? DEFAULT_ITERATIONS;
  }

  private iso(): string {
    return this.nowFn().toISOString();
  }

  async init(): Promise<void> {
    await migrate(this.db, () => this.iso());
  }

  // ---------------------------------------------------------------- helpers
  private toUser(r: Row): PublicUser {
    return {
      id: r.id,
      username: r.username,
      displayName: r.display_name,
      status: r.status,
      isOwner: r.is_owner === 1,
      isTest: r.is_test === 1,
      createdAt: r.created_at,
      memberSinceDisplay: r.member_since_display ?? null,
      bio: r.bio,
      avatarColor: r.avatar_color,
    };
  }

  private async userRow(id: string): Promise<Row | undefined> {
    return (await this.db.all(`SELECT * FROM users WHERE id = ?`, [id]))[0];
  }

  private async audit(actor: { id: string | null; name: string }, action: string, target = "", detail = ""): Promise<void> {
    await this.db.run(`INSERT INTO audit_log (actor_id, actor_name, action, target, detail, created_at) VALUES (?,?,?,?,?,?)`, [actor.id, actor.name, action, target, detail, this.iso()]);
  }

  private validateUsername(u: string): string {
    const v = u.trim();
    if (!USERNAME_RE.test(v)) err("INVALID_INPUT", "Username must be 3-24 characters: letters, numbers, . _ -");
    return v;
  }
  private validateDisplay(n: string): string {
    const v = n.trim();
    if (v.length < 1 || v.length > 32) err("INVALID_INPUT", "Display name must be 1-32 characters");
    return v;
  }
  private validatePassword(p: string, min = 8): void {
    if (typeof p !== "string" || p.length < min || p.length > 200) err("INVALID_INPUT", `Password must be at least ${min} characters`);
  }
  private validateDate(s: string): string {
    const d = new Date(s);
    if (Number.isNaN(d.getTime())) err("INVALID_INPUT", "Invalid date");
    if (d.getFullYear() < 2000 || d.getFullYear() > 2100) err("INVALID_INPUT", "Date must be between 2000 and 2100");
    return d.toISOString();
  }

  // ---------------------------------------------------------------- auth
  async isFirstRun(): Promise<boolean> {
    const r = await this.db.all<{ n: number }>(`SELECT COUNT(*) AS n FROM users WHERE is_owner = 1`);
    return (r[0]?.n ?? 0) === 0;
  }

  /** First-run only: creates the single Owner with a password chosen by the person holding the device. */
  async setupOwner(username: string, displayName: string, password: string): Promise<PublicUser> {
    if (!(await this.isFirstRun())) err("FORBIDDEN", "Setup already completed");
    const uname = this.validateUsername(username);
    const dname = this.validateDisplay(displayName);
    this.validatePassword(password, 10);
    const rec = await hashPassword(password, this.iterations);
    const id = newId();
    await this.db.transaction(async () => {
      await this.db.run(
        `INSERT INTO users (id, username, display_name, password_hash, password_salt, iterations, is_owner, created_at) VALUES (?,?,?,?,?,?,1,?)`,
        [id, uname, dname, rec.hash, rec.salt, rec.iterations, this.iso()],
      );
      await this.audit({ id, name: dname }, "owner.setup", uname);
    });
    this.sessionUserId = id;
    this.adminUntil = this.nowFn().getTime() + ADMIN_UNLOCK_MS;
    return this.toUser((await this.userRow(id))!);
  }

  async register(username: string, displayName: string, password: string): Promise<PublicUser> {
    if (await this.isFirstRun()) err("FORBIDDEN", "Complete first-run setup first");
    const uname = this.validateUsername(username);
    const dname = this.validateDisplay(displayName);
    this.validatePassword(password);
    const rec = await hashPassword(password, this.iterations);
    const id = newId();
    await this.db.transaction(async () => {
      await this.insertUser(id, uname, dname, rec, false, null);
      await this.audit({ id, name: dname }, "account.register", uname);
    });
    return this.toUser((await this.userRow(id))!);
  }

  private async insertUser(id: string, uname: string, dname: string, rec: { hash: string; salt: string; iterations: number }, isTest: boolean, memberSince: string | null): Promise<void> {
    const exists = await this.db.all(`SELECT 1 FROM users WHERE username = ? COLLATE NOCASE`, [uname]);
    if (exists.length) err("USERNAME_TAKEN", "Username already taken");
    await this.db.run(
      `INSERT INTO users (id, username, display_name, password_hash, password_salt, iterations, is_test, created_at, member_since_display) VALUES (?,?,?,?,?,?,?,?,?)`,
      [id, uname, dname, rec.hash, rec.salt, rec.iterations, isTest ? 1 : 0, this.iso(), memberSince],
    );
  }

  async login(username: string, password: string): Promise<PublicUser> {
    const key = username.trim().toLowerCase();
    const f = this.fails.get(key);
    if (f && f.until > this.nowFn().getTime()) err("RATE_LIMITED", "Too many attempts. Try again in a moment.");
    const row = (await this.db.all(`SELECT * FROM users WHERE username = ? COLLATE NOCASE`, [username.trim()]))[0];
    const ok = row
      ? await verifyPassword(password, { hash: row.password_hash, salt: row.password_salt, iterations: row.iterations })
      : (await hashPassword(password, this.iterations), false); // equalize timing
    if (!row || !ok) {
      const c = (f?.count ?? 0) + 1;
      this.fails.set(key, { count: c, until: c >= 5 ? this.nowFn().getTime() + 30_000 : 0 });
      err("BAD_CREDENTIALS", "Wrong username or password");
    }
    this.fails.delete(key);
    if (row.status === "banned") err("ACCOUNT_BANNED", "This account is banned");
    if (row.status === "suspended") err("ACCOUNT_SUSPENDED", "This account is suspended");
    this.sessionUserId = row.id;
    this.adminUntil = 0;
    return this.toUser(row);
  }

  logout(): void {
    this.sessionUserId = null;
    this.adminUntil = 0;
  }

  async currentUser(): Promise<PublicUser | null> {
    if (!this.sessionUserId) return null;
    const r = await this.userRow(this.sessionUserId);
    if (!r || r.status !== "active") {
      this.logout();
      return null;
    }
    return this.toUser(r);
  }

  private async requireUser(): Promise<PublicUser> {
    const u = await this.currentUser();
    if (!u) err("NOT_AUTHENTICATED", "Please log in");
    return u;
  }

  async updateProfile(p: { displayName?: string; bio?: string; avatarColor?: string }): Promise<PublicUser> {
    const u = await this.requireUser();
    const dn = p.displayName === undefined ? u.displayName : this.validateDisplay(p.displayName);
    const bio = p.bio === undefined ? u.bio : p.bio.slice(0, 300);
    const col = p.avatarColor === undefined ? u.avatarColor : p.avatarColor;
    if (!/^#[0-9a-f]{6}$/i.test(col)) err("INVALID_INPUT", "Invalid color");
    await this.db.run(`UPDATE users SET display_name = ?, bio = ?, avatar_color = ? WHERE id = ?`, [dn, bio, col, u.id]);
    return (await this.currentUser())!;
  }

  async changePassword(oldPw: string, newPw: string): Promise<void> {
    const u = await this.requireUser();
    this.validatePassword(newPw, u.isOwner ? 10 : 8);
    const row = (await this.userRow(u.id))!;
    if (!(await verifyPassword(oldPw, { hash: row.password_hash, salt: row.password_salt, iterations: row.iterations }))) err("BAD_CREDENTIALS", "Current password is wrong");
    const rec = await hashPassword(newPw, this.iterations);
    await this.db.transaction(async () => {
      await this.db.run(`UPDATE users SET password_hash=?, password_salt=?, iterations=? WHERE id=?`, [rec.hash, rec.salt, rec.iterations, u.id]);
      await this.audit({ id: u.id, name: u.displayName }, "account.password_change", u.username);
    });
  }

  // ---------------------------------------------------------------- owner gate
  /** Owner must re-enter their password to unlock admin actions for 5 minutes. */
  async unlockAdmin(password: string): Promise<void> {
    const u = await this.requireUser();
    if (!u.isOwner) err("FORBIDDEN", "Owner only");
    const row = (await this.userRow(u.id))!;
    if (!(await verifyPassword(password, { hash: row.password_hash, salt: row.password_salt, iterations: row.iterations }))) err("BAD_CREDENTIALS", "Wrong password");
    this.adminUntil = this.nowFn().getTime() + ADMIN_UNLOCK_MS;
    await this.audit({ id: u.id, name: u.displayName }, "admin.unlock");
  }

  lockAdmin(): void {
    this.adminUntil = 0;
  }

  isAdminUnlocked(): boolean {
    return this.adminUntil > this.nowFn().getTime();
  }

  /** Every privileged method calls this first. */
  private async requireOwner(): Promise<PublicUser> {
    const u = await this.requireUser();
    if (!u.isOwner) err("FORBIDDEN", "Owner only");
    if (!this.isAdminUnlocked()) err("ADMIN_LOCKED", "Re-enter your password to unlock admin actions");
    return u;
  }

  private actor(u: PublicUser) {
    return { id: u.id, name: u.displayName };
  }

  private async targetUser(id: string): Promise<Row> {
    const r = await this.userRow(id);
    if (!r) err("NOT_FOUND", "Account not found");
    return r;
  }

  // ---------------------------------------------------------------- owner: accounts
  async listUsers(): Promise<PublicUser[]> {
    await this.requireOwner();
    return (await this.db.all(`SELECT * FROM users ORDER BY created_at ASC`)).map((r) => this.toUser(r));
  }

  async createUser(p: { username: string; displayName: string; password: string; memberSince?: string | null }): Promise<PublicUser> {
    const o = await this.requireOwner();
    const uname = this.validateUsername(p.username);
    const dname = this.validateDisplay(p.displayName);
    this.validatePassword(p.password);
    const ms = p.memberSince ? this.validateDate(p.memberSince) : null;
    const rec = await hashPassword(p.password, this.iterations);
    const id = newId();
    await this.db.transaction(async () => {
      await this.insertUser(id, uname, dname, rec, false, ms);
      await this.audit(this.actor(o), "user.create", uname);
    });
    return this.toUser((await this.userRow(id))!);
  }

  async updateUser(id: string, p: { username?: string; displayName?: string }): Promise<PublicUser> {
    const o = await this.requireOwner();
    const t = await this.targetUser(id);
    const uname = p.username === undefined ? t.username : this.validateUsername(p.username);
    const dname = p.displayName === undefined ? t.display_name : this.validateDisplay(p.displayName);
    await this.db.transaction(async () => {
      if (uname.toLowerCase() !== String(t.username).toLowerCase()) {
        if ((await this.db.all(`SELECT 1 FROM users WHERE username = ? COLLATE NOCASE AND id <> ?`, [uname, id])).length) err("USERNAME_TAKEN", "Username already taken");
      }
      await this.db.run(`UPDATE users SET username = ?, display_name = ? WHERE id = ?`, [uname, dname, id]);
      await this.audit(this.actor(o), "user.update", t.username, `username ${t.username} -> ${uname}; display "${t.display_name}" -> "${dname}"`);
    });
    return this.toUser((await this.userRow(id))!);
  }

  async resetPassword(id: string, newPassword: string): Promise<void> {
    const o = await this.requireOwner();
    const t = await this.targetUser(id);
    this.validatePassword(newPassword, t.is_owner === 1 ? 10 : 8);
    const rec = await hashPassword(newPassword, this.iterations);
    await this.db.transaction(async () => {
      await this.db.run(`UPDATE users SET password_hash=?, password_salt=?, iterations=? WHERE id=?`, [rec.hash, rec.salt, rec.iterations, id]);
      await this.audit(this.actor(o), "user.reset_password", t.username);
    });
  }

  async setStatus(id: string, status: Status): Promise<void> {
    const o = await this.requireOwner();
    const t = await this.targetUser(id);
    if (t.is_owner === 1) err("FORBIDDEN", "The Owner account cannot be suspended or banned");
    if (!["active", "suspended", "banned"].includes(status)) err("INVALID_INPUT", "Invalid status");
    const action = status === "active" ? "user.restore" : status === "suspended" ? "user.suspend" : "user.ban";
    await this.db.transaction(async () => {
      await this.db.run(`UPDATE users SET status = ? WHERE id = ?`, [status, id]);
      await this.audit(this.actor(o), action, t.username, `${t.status} -> ${status}`);
    });
  }

  /** Destructive: caller must pass the exact username as typed confirmation. */
  async deleteUser(id: string, confirmUsername: string): Promise<void> {
    const o = await this.requireOwner();
    const t = await this.targetUser(id);
    if (t.is_owner === 1) err("FORBIDDEN", "The Owner account cannot be deleted");
    if (confirmUsername !== t.username) err("CONFIRMATION_FAILED", "Confirmation text does not match the username");
    await this.db.transaction(async () => {
      await this.removeUsers([id]);
      await this.audit(this.actor(o), "user.delete", t.username);
    });
  }

  private async removeUsers(ids: string[]): Promise<void> {
    for (const id of ids) {
      await this.db.run(`UPDATE messages SET author_id = NULL WHERE author_id = ?`, [id]); // keep history, keep author_name snapshot
      await this.db.run(`DELETE FROM members WHERE user_id = ?`, [id]);
      await this.db.run(`DELETE FROM users WHERE id = ? AND is_owner = 0`, [id]);
    }
  }

  /** Changes ONLY the displayed date. created_at is never touched. */
  async setMemberSince(id: string, date: string | null): Promise<PublicUser> {
    const o = await this.requireOwner();
    const t = await this.targetUser(id);
    const next = date === null || date === "" ? null : this.validateDate(date);
    await this.db.transaction(async () => {
      await this.db.run(`UPDATE users SET member_since_display = ? WHERE id = ?`, [next, id]);
      await this.audit(this.actor(o), "user.set_member_since", t.username, `displayed ${t.member_since_display ?? "(real date)"} -> ${next ?? "(real date)"}`);
    });
    return this.toUser((await this.userRow(id))!);
  }

  async generateTestAccounts(p: { count: number; prefix: string; password: string; memberSince?: string | null }): Promise<string[]> {
    const o = await this.requireOwner();
    if (!Number.isInteger(p.count) || p.count < 1 || p.count > MAX_TEST_BATCH) err("INVALID_INPUT", `Batch size must be 1-${MAX_TEST_BATCH}`);
    const prefix = p.prefix.trim().toLowerCase();
    if (!/^[a-z0-9_.-]{1,16}$/.test(prefix)) err("INVALID_INPUT", "Prefix must be 1-16 characters: letters, numbers, . _ -");
    this.validatePassword(p.password);
    const ms = p.memberSince ? this.validateDate(p.memberSince) : null;
    const existing = new Set((await this.db.all<{ u: string }>(`SELECT LOWER(username) AS u FROM users`)).map((r) => r.u));
    const names: string[] = [];
    for (let n = 1; names.length < p.count; n++) {
      const name = `${prefix}${n}`;
      if (!existing.has(name)) names.push(name);
    }
    const prepared: Array<{ id: string; name: string; rec: Awaited<ReturnType<typeof hashPassword>> }> = [];
    for (const name of names) prepared.push({ id: newId(), name, rec: await hashPassword(p.password, this.iterations) });
    await this.db.transaction(async () => {
      for (const x of prepared) await this.insertUser(x.id, x.name, `Test ${x.name}`, x.rec, true, ms);
      await this.audit(this.actor(o), "user.generate_test_accounts", prefix, `count=${p.count}`);
    });
    return names;
  }

  async deleteAllTestAccounts(confirm: string): Promise<number> {
    const o = await this.requireOwner();
    if (confirm !== "DELETE TEST ACCOUNTS") err("CONFIRMATION_FAILED", "Type DELETE TEST ACCOUNTS to confirm");
    let n = 0;
    await this.db.transaction(async () => {
      const ids = (await this.db.all<{ id: string }>(`SELECT id FROM users WHERE is_test = 1 AND is_owner = 0`)).map((r) => r.id);
      await this.removeUsers(ids);
      n = ids.length;
      await this.audit(this.actor(o), "user.delete_test_accounts", "", `count=${n}`);
    });
    return n;
  }

  async listAudit(limit = 200): Promise<Array<{ seq: number; actorName: string; action: string; target: string; detail: string; createdAt: string }>> {
    await this.requireOwner();
    const rows = await this.db.all(`SELECT * FROM audit_log ORDER BY seq DESC LIMIT ?`, [Math.min(Math.max(limit, 1), 1000)]);
    return rows.map((r) => ({ seq: r.seq, actorName: r.actor_name, action: r.action, target: r.target, detail: r.detail, createdAt: r.created_at }));
  }

  // ---------------------------------------------------------------- branding
  async getBranding(): Promise<Branding> {
    const rows = await this.db.all<{ key: string; value: string }>(`SELECT key, value FROM settings WHERE key LIKE 'brand.%'`);
    const m = new Map(rows.map((r) => [r.key, r.value]));
    return {
      name: m.get("brand.name") ?? DEFAULT_BRANDING.name,
      tagline: m.get("brand.tagline") ?? DEFAULT_BRANDING.tagline,
      accent: m.get("brand.accent") ?? DEFAULT_BRANDING.accent,
      logo: m.get("brand.logo") ?? null,
    };
  }

  async setBranding(p: Partial<Branding>): Promise<Branding> {
    const o = await this.requireOwner();
    const cur = await this.getBranding();
    const next: Branding = { ...cur, ...p };
    if (next.name.trim().length < 1 || next.name.length > 40) err("INVALID_INPUT", "App name must be 1-40 characters");
    if (next.tagline.length > 80) err("INVALID_INPUT", "Tagline too long");
    if (!/^#[0-9a-f]{6}$/i.test(next.accent)) err("INVALID_INPUT", "Accent must look like #5865f2");
    if (next.logo !== null && !/^data:image\/(png|jpeg|webp);base64,[A-Za-z0-9+/=]+$/.test(next.logo)) err("INVALID_INPUT", "Logo must be a PNG, JPEG or WebP image");
    if (next.logo !== null && next.logo.length > 300_000) err("INVALID_INPUT", "Logo is too large (max ~200 KB)");
    await this.db.transaction(async () => {
      const entries: Array<[string, string | null]> = [["brand.name", next.name.trim()], ["brand.tagline", next.tagline], ["brand.accent", next.accent], ["brand.logo", next.logo]];
      for (const [k, v] of entries) {
        if (v === null) await this.db.run(`DELETE FROM settings WHERE key = ?`, [k]);
        else await this.db.run(`INSERT INTO settings (key, value) VALUES (?, ?) ON CONFLICT(key) DO UPDATE SET value = excluded.value`, [k, v]);
      }
      await this.audit(this.actor(o), "branding.update", next.name);
    });
    return this.getBranding();
  }

  // ---------------------------------------------------------------- workspaces
  private async wsAccess(wsId: string, u: PublicUser): Promise<number> {
    const ws = (await this.db.all(`SELECT * FROM workspaces WHERE id = ?`, [wsId]))[0];
    if (!ws) err("NOT_FOUND", "Workspace not found");
    if (u.isOwner || ws.owner_id === u.id) return ALL_PERMS;
    const r = (await this.db.all(`SELECT r.permissions AS p FROM members m JOIN roles r ON r.id = m.role_id WHERE m.workspace_id = ? AND m.user_id = ?`, [wsId, u.id]))[0];
    if (!r) err("NOT_MEMBER", "You are not a member of this workspace");
    return r.p;
  }

  private async requirePerm(wsId: string, perm: number): Promise<{ u: PublicUser; mask: number }> {
    const u = await this.requireUser();
    const mask = await this.wsAccess(wsId, u);
    if (!has(mask, perm)) err("FORBIDDEN", "You do not have permission to do that");
    return { u, mask };
  }

  async createWorkspace(name: string): Promise<{ id: string; name: string }> {
    const u = await this.requireUser();
    const n = name.trim();
    if (n.length < 1 || n.length > 40) err("INVALID_INPUT", "Workspace name must be 1-40 characters");
    const id = newId();
    const adminRole = newId();
    const memberRole = newId();
    const t = this.iso();
    await this.db.transaction(async () => {
      await this.db.run(`INSERT INTO workspaces (id, name, owner_id, created_at) VALUES (?,?,?,?)`, [id, n, u.id, t]);
      await this.db.run(`INSERT INTO roles (id, workspace_id, name, permissions, is_default, created_at) VALUES (?,?,?,?,0,?)`, [adminRole, id, "Admin", Perm.ADMIN, t]);
      await this.db.run(`INSERT INTO roles (id, workspace_id, name, permissions, is_default, created_at) VALUES (?,?,?,?,1,?)`, [memberRole, id, "Member", Perm.VIEW | Perm.SEND, t]);
      await this.db.run(`INSERT INTO members (workspace_id, user_id, role_id, joined_at) VALUES (?,?,?,?)`, [id, u.id, adminRole, t]);
      await this.db.run(`INSERT INTO channels (id, workspace_id, name, created_at) VALUES (?,?,?,?)`, [newId(), id, "general", t]);
      await this.audit(this.actor(u), "workspace.create", n);
    });
    return { id, name: n };
  }

  async myWorkspaces(): Promise<Array<{ id: string; name: string }>> {
    const u = await this.requireUser();
    const rows = u.isOwner
      ? await this.db.all(`SELECT id, name FROM workspaces ORDER BY created_at`)
      : await this.db.all(`SELECT w.id, w.name FROM workspaces w JOIN members m ON m.workspace_id = w.id WHERE m.user_id = ? ORDER BY w.created_at`, [u.id]);
    return rows.map((r) => ({ id: r.id, name: r.name }));
  }

  async joinableWorkspaces(): Promise<Array<{ id: string; name: string }>> {
    const u = await this.requireUser();
    const rows = await this.db.all(`SELECT id, name FROM workspaces WHERE id NOT IN (SELECT workspace_id FROM members WHERE user_id = ?) ORDER BY name`, [u.id]);
    return rows.map((r) => ({ id: r.id, name: r.name }));
  }

  async joinWorkspace(wsId: string): Promise<void> {
    const u = await this.requireUser();
    if (!(await this.db.all(`SELECT 1 FROM workspaces WHERE id = ?`, [wsId])).length) err("NOT_FOUND", "Workspace not found");
    const role = (await this.db.all(`SELECT id FROM roles WHERE workspace_id = ? AND is_default = 1`, [wsId]))[0];
    if (!role) err("NOT_FOUND", "Workspace has no default role");
    if ((await this.db.all(`SELECT 1 FROM members WHERE workspace_id = ? AND user_id = ?`, [wsId, u.id])).length) return;
    await this.db.run(`INSERT INTO members (workspace_id, user_id, role_id, joined_at) VALUES (?,?,?,?)`, [wsId, u.id, role.id, this.iso()]);
  }

  async deleteWorkspace(wsId: string, confirmName: string): Promise<void> {
    const u = await this.requireUser();
    const ws = (await this.db.all(`SELECT * FROM workspaces WHERE id = ?`, [wsId]))[0];
    if (!ws) err("NOT_FOUND", "Workspace not found");
    if (!u.isOwner && ws.owner_id !== u.id) err("FORBIDDEN", "Only the workspace owner can delete it");
    if (confirmName !== ws.name) err("CONFIRMATION_FAILED", "Confirmation text does not match the workspace name");
    await this.db.transaction(async () => {
      await this.db.run(`DELETE FROM messages WHERE channel_id IN (SELECT id FROM channels WHERE workspace_id = ?)`, [wsId]);
      await this.db.run(`DELETE FROM channels WHERE workspace_id = ?`, [wsId]);
      await this.db.run(`DELETE FROM members WHERE workspace_id = ?`, [wsId]);
      await this.db.run(`DELETE FROM roles WHERE workspace_id = ?`, [wsId]);
      await this.db.run(`DELETE FROM workspaces WHERE id = ?`, [wsId]);
      await this.audit(this.actor(u), "workspace.delete", ws.name);
    });
  }

  // ---------------------------------------------------------------- channels & messages
  async listChannels(wsId: string): Promise<Array<{ id: string; name: string }>> {
    await this.requirePerm(wsId, Perm.VIEW);
    return (await this.db.all(`SELECT id, name FROM channels WHERE workspace_id = ? ORDER BY created_at, name`, [wsId])).map((r) => ({ id: r.id, name: r.name }));
  }

  async createChannel(wsId: string, name: string): Promise<{ id: string; name: string }> {
    const { u } = await this.requirePerm(wsId, Perm.MANAGE_CHANNELS);
    const n = name.trim().toLowerCase().replace(/\s+/g, "-");
    if (!/^[a-z0-9_-]{1,32}$/.test(n)) err("INVALID_INPUT", "Channel name: 1-32 characters, letters, numbers, - _");
    if ((await this.db.all(`SELECT 1 FROM channels WHERE workspace_id = ? AND name = ?`, [wsId, n])).length) err("NAME_TAKEN", "Channel already exists");
    const id = newId();
    await this.db.transaction(async () => {
      await this.db.run(`INSERT INTO channels (id, workspace_id, name, created_at) VALUES (?,?,?,?)`, [id, wsId, n, this.iso()]);
      await this.audit(this.actor(u), "channel.create", n, wsId);
    });
    return { id, name: n };
  }

  private async channelWs(channelId: string): Promise<{ wsId: string; name: string }> {
    const c = (await this.db.all(`SELECT workspace_id, name FROM channels WHERE id = ?`, [channelId]))[0];
    if (!c) err("NOT_FOUND", "Channel not found");
    return { wsId: c.workspace_id, name: c.name };
  }

  async deleteChannel(channelId: string): Promise<void> {
    const c = await this.channelWs(channelId);
    const { u } = await this.requirePerm(c.wsId, Perm.MANAGE_CHANNELS);
    await this.db.transaction(async () => {
      await this.db.run(`DELETE FROM messages WHERE channel_id = ?`, [channelId]);
      await this.db.run(`DELETE FROM channels WHERE id = ?`, [channelId]);
      await this.audit(this.actor(u), "channel.delete", c.name, c.wsId);
    });
  }

  async sendMessage(channelId: string, body: string): Promise<void> {
    const c = await this.channelWs(channelId);
    const { u } = await this.requirePerm(c.wsId, Perm.SEND);
    const text = body.trim();
    if (text.length < 1 || text.length > 4000) err("INVALID_INPUT", "Message must be 1-4000 characters");
    await this.db.run(`INSERT INTO messages (id, channel_id, author_id, author_name, body, created_at) VALUES (?,?,?,?,?,?)`, [newId(), channelId, u.id, u.displayName, text, this.iso()]);
  }

  async listMessages(channelId: string, limit = 100): Promise<Array<{ id: string; authorId: string | null; authorName: string; body: string; createdAt: string }>> {
    const c = await this.channelWs(channelId);
    await this.requirePerm(c.wsId, Perm.VIEW);
    const rows = await this.db.all(
      `SELECT m.id, m.author_id, COALESCE(u.display_name, m.author_name) AS name, m.body, m.created_at FROM messages m LEFT JOIN users u ON u.id = m.author_id WHERE m.channel_id = ? ORDER BY m.seq DESC LIMIT ?`,
      [channelId, Math.min(Math.max(limit, 1), 500)],
    );
    return rows.reverse().map((r) => ({ id: r.id, authorId: r.author_id, authorName: r.name, body: r.body, createdAt: r.created_at }));
  }

  async deleteMessage(messageId: string): Promise<void> {
    const m = (await this.db.all(`SELECT m.author_id, c.workspace_id AS ws FROM messages m JOIN channels c ON c.id = m.channel_id WHERE m.id = ?`, [messageId]))[0];
    if (!m) err("NOT_FOUND", "Message not found");
    const { u, mask } = await this.requirePerm(m.ws, Perm.VIEW);
    if (m.author_id !== u.id && !has(mask, Perm.MANAGE_MESSAGES)) err("FORBIDDEN", "You can only delete your own messages");
    await this.db.run(`DELETE FROM messages WHERE id = ?`, [messageId]);
  }

  // ---------------------------------------------------------------- roles & members
  async listRoles(wsId: string): Promise<Array<{ id: string; name: string; permissions: number; isDefault: boolean }>> {
    await this.requirePerm(wsId, Perm.VIEW);
    return (await this.db.all(`SELECT * FROM roles WHERE workspace_id = ? ORDER BY created_at`, [wsId])).map((r) => ({ id: r.id, name: r.name, permissions: r.permissions, isDefault: r.is_default === 1 }));
  }

  async listMembers(wsId: string): Promise<Array<{ userId: string; displayName: string; roleId: string; roleName: string }>> {
    await this.requirePerm(wsId, Perm.VIEW);
    const rows = await this.db.all(`SELECT u.id AS uid, u.display_name AS dn, r.id AS rid, r.name AS rn FROM members m JOIN users u ON u.id = m.user_id JOIN roles r ON r.id = m.role_id WHERE m.workspace_id = ? ORDER BY u.display_name`, [wsId]);
    return rows.map((r) => ({ userId: r.uid, displayName: r.dn, roleId: r.rid, roleName: r.rn }));
  }

  private checkPermMask(p: number): number {
    if (!Number.isInteger(p) || p < 0 || p > ALL_PERMS) err("INVALID_INPUT", "Invalid permissions");
    return p;
  }

  async createRole(wsId: string, name: string, permissions: number): Promise<string> {
    const { u, mask } = await this.requirePerm(wsId, Perm.MANAGE_ROLES);
    const n = name.trim();
    if (n.length < 1 || n.length > 30) err("INVALID_INPUT", "Role name must be 1-30 characters");
    this.checkPermMask(permissions);
    if (!isSubset(permissions, mask)) err("FORBIDDEN", "You cannot grant permissions you do not have");
    const id = newId();
    await this.db.transaction(async () => {
      await this.db.run(`INSERT INTO roles (id, workspace_id, name, permissions, is_default, created_at) VALUES (?,?,?,?,0,?)`, [id, wsId, n, permissions, this.iso()]);
      await this.audit(this.actor(u), "role.create", n, `ws=${wsId} perms=${permissions}`);
    });
    return id;
  }

  async updateRolePermissions(roleId: string, permissions: number): Promise<void> {
    const role = (await this.db.all(`SELECT * FROM roles WHERE id = ?`, [roleId]))[0];
    if (!role) err("NOT_FOUND", "Role not found");
    const { u, mask } = await this.requirePerm(role.workspace_id, Perm.MANAGE_ROLES);
    this.checkPermMask(permissions);
    if (!isSubset(permissions, mask) || !isSubset(role.permissions, mask)) err("FORBIDDEN", "You cannot edit a role beyond your own permissions");
    await this.db.transaction(async () => {
      await this.db.run(`UPDATE roles SET permissions = ? WHERE id = ?`, [permissions, roleId]);
      await this.audit(this.actor(u), "role.update", role.name, `ws=${role.workspace_id} ${role.permissions} -> ${permissions}`);
    });
  }

  async deleteRole(roleId: string): Promise<void> {
    const role = (await this.db.all(`SELECT * FROM roles WHERE id = ?`, [roleId]))[0];
    if (!role) err("NOT_FOUND", "Role not found");
    const { u, mask } = await this.requirePerm(role.workspace_id, Perm.MANAGE_ROLES);
    if (role.is_default === 1) err("FORBIDDEN", "The default role cannot be deleted");
    if (!isSubset(role.permissions, mask)) err("FORBIDDEN", "You cannot delete a role beyond your own permissions");
    const def = (await this.db.all(`SELECT id FROM roles WHERE workspace_id = ? AND is_default = 1`, [role.workspace_id]))[0];
    await this.db.transaction(async () => {
      await this.db.run(`UPDATE members SET role_id = ? WHERE role_id = ?`, [def.id, roleId]);
      await this.db.run(`DELETE FROM roles WHERE id = ?`, [roleId]);
      await this.audit(this.actor(u), "role.delete", role.name, `ws=${role.workspace_id}`);
    });
  }

  async assignRole(wsId: string, userId: string, roleId: string): Promise<void> {
    const { u, mask } = await this.requirePerm(wsId, Perm.MANAGE_ROLES);
    const role = (await this.db.all(`SELECT * FROM roles WHERE id = ? AND workspace_id = ?`, [roleId, wsId]))[0];
    if (!role) err("NOT_FOUND", "Role not found in this workspace");
    if (!isSubset(role.permissions, mask)) err("FORBIDDEN", "You cannot assign a role with permissions you do not have");
    const ws = (await this.db.all(`SELECT owner_id FROM workspaces WHERE id = ?`, [wsId]))[0];
    const target = await this.userRow(userId);
    if (!target || !(await this.db.all(`SELECT 1 FROM members WHERE workspace_id = ? AND user_id = ?`, [wsId, userId])).length) err("NOT_FOUND", "Member not found");
    const actorIsTop = u.isOwner || ws.owner_id === u.id;
    if ((ws.owner_id === userId || target.is_owner === 1) && !actorIsTop) err("FORBIDDEN", "You cannot change the workspace owner's role");
    // Current role of the target must also be within the actor's permissions.
    const cur = (await this.db.all(`SELECT r.permissions AS p FROM members m JOIN roles r ON r.id = m.role_id WHERE m.workspace_id = ? AND m.user_id = ?`, [wsId, userId]))[0];
    if (cur && !isSubset(cur.p, mask)) err("FORBIDDEN", "You cannot change a member who outranks you");
    await this.db.transaction(async () => {
      await this.db.run(`UPDATE members SET role_id = ? WHERE workspace_id = ? AND user_id = ?`, [roleId, wsId, userId]);
      await this.audit(this.actor(u), "role.assign", target.username, `ws=${wsId} role=${role.name}`);
    });
  }

  // ---------------------------------------------------------------- backup / restore
  async exportBackup(): Promise<string> {
    const o = await this.requireOwner();
    const tables: Record<string, Row[]> = {};
    for (const t of TABLE_ORDER) tables[t] = await this.db.all(`SELECT ${TABLES[t].join(", ")} FROM ${t}`);
    await this.audit(this.actor(o), "backup.export");
    return JSON.stringify({ format: BACKUP_FORMAT, version: BACKUP_VERSION, exportedAt: this.iso(), tables });
  }

  async restoreBackup(json: string, confirm: string): Promise<void> {
    const o = await this.requireOwner();
    if (confirm !== "RESTORE") err("CONFIRMATION_FAILED", "Type RESTORE to confirm");
    let data: any;
    try {
      data = JSON.parse(json);
    } catch {
      err("INVALID_BACKUP", "File is not valid JSON");
    }
    if (!data || data.format !== BACKUP_FORMAT || data.version !== BACKUP_VERSION || typeof data.tables !== "object" || data.tables === null) err("INVALID_BACKUP", "Not an OfflineHub backup (or unsupported version)");
    for (const t of TABLE_ORDER) {
      const rows = data.tables[t];
      if (!Array.isArray(rows)) err("INVALID_BACKUP", `Missing table: ${t}`);
      for (const row of rows) {
        if (typeof row !== "object" || row === null) err("INVALID_BACKUP", `Bad row in ${t}`);
        const keys = Object.keys(row);
        if (keys.length !== TABLES[t].length || !TABLES[t].every((c) => c in row)) err("INVALID_BACKUP", `Unexpected columns in ${t}`);
        for (const k of keys) {
          const v = row[k];
          if (v !== null && typeof v !== "string" && typeof v !== "number") err("INVALID_BACKUP", `Bad value in ${t}.${k}`);
        }
      }
    }
    const owners = (data.tables.users as Row[]).filter((r) => r.is_owner === 1 && r.status === "active");
    if (owners.length !== 1) err("INVALID_BACKUP", "Backup must contain exactly one active Owner account");
    const hasDefaultStatus = (data.tables.users as Row[]).every((r) => ["active", "suspended", "banned"].includes(r.status));
    if (!hasDefaultStatus) err("INVALID_BACKUP", "Backup contains an invalid account status");

    await this.db.transaction(async () => {
      for (const t of [...TABLE_ORDER].reverse()) await this.db.run(`DELETE FROM ${t}`);
      await this.db.run(`DELETE FROM sqlite_sequence WHERE name IN ('messages','audit_log')`).catch(() => undefined);
      for (const t of TABLE_ORDER) {
        const cols = TABLES[t];
        const sql = `INSERT INTO ${t} (${cols.join(", ")}) VALUES (${cols.map(() => "?").join(", ")})`;
        for (const row of data.tables[t] as Row[]) await this.db.run(sql, cols.map((c) => row[c] as SqlValue));
      }
      await this.audit({ id: null, name: "system" }, "backup.restore", "", `by ${o.username}`);
    });
    this.logout(); // restored data may differ; force a fresh login
  }
}
