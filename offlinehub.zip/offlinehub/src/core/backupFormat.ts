// Tables and the exact columns that are allowed in a backup file (allowlist; nothing else is ever inserted).
export const TABLES = {
  users: ["id", "username", "display_name", "password_hash", "password_salt", "iterations", "status", "is_owner", "is_test", "created_at", "member_since_display", "bio", "avatar_color"],
  workspaces: ["id", "name", "owner_id", "created_at"],
  roles: ["id", "workspace_id", "name", "permissions", "is_default", "created_at"],
  members: ["workspace_id", "user_id", "role_id", "joined_at"],
  channels: ["id", "workspace_id", "name", "created_at"],
  messages: ["seq", "id", "channel_id", "author_id", "author_name", "body", "created_at"],
  audit_log: ["seq", "actor_id", "actor_name", "action", "target", "detail", "created_at"],
  settings: ["key", "value"],
} as const;

export type TableName = keyof typeof TABLES;
export const TABLE_ORDER: TableName[] = ["users", "workspaces", "roles", "members", "channels", "messages", "audit_log", "settings"];
export const BACKUP_FORMAT = "offlinehub-backup";
export const BACKUP_VERSION = 1;
