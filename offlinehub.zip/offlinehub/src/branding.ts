// Default branding. The Owner can override name, tagline, accent color and logo in the Owner dashboard (stored locally).
export { DEFAULT_BRANDING } from "./core/hub.ts";
