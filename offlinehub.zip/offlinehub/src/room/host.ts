import { generateRoomCode, isValidCodeFormat } from "./code.ts";
import {
  HISTORY_LIMIT,
  MAX_GUESTS,
  cleanChat,
  cleanJoinInfo,
  type ChatMessage,
  type Peer,
  type ServerMsg,
} from "./protocol.ts";

/** One guest connection as the host sees it. The transport (Wi-Fi/hotspot) implements this. */
export interface HostConn {
  send(m: ServerMsg): void;
  close(): void;
}

export type HostEvent =
  | { t: "members"; members: Peer[]; guests: number; max: number }
  | { t: "chat"; msg: ChatMessage };

export interface HostOptions {
  hostName: string;
  hostColor: string;
  code?: string;
  maxGuests?: number;
  now?: () => number;
  newId?: () => string;
}

const MAX_STRIKES_PER_CONN = 3; // wrong codes before that connection is dropped
const GLOBAL_STRIKE_LIMIT = 10; // wrong codes (all connections together) before joins lock
const LOCK_MS = 30_000;

/**
 * The room owner's side. Holds the code, decides who may join (max 4 guests),
 * and relays chat. Everything a guest sends is treated as untrusted input.
 */
export class RoomHost {
  readonly code: string;
  readonly maxGuests: number;
  private hostPeer: Peer;
  private guests = new Map<HostConn, Peer>();
  private strikes = new Map<HostConn, number>();
  private history: ChatMessage[] = [];
  private listeners = new Set<(e: HostEvent) => void>();
  private isOpen = true;
  private globalStrikes = 0;
  private lockedUntil = 0;
  private now: () => number;
  private newId: () => string;

  constructor(o: HostOptions) {
    this.code = o.code ?? generateRoomCode();
    this.maxGuests = o.maxGuests ?? MAX_GUESTS;
    this.now = o.now ?? (() => Date.now());
    this.newId = o.newId ?? (() => crypto.randomUUID());
    this.hostPeer = { id: this.newId(), displayName: o.hostName, avatarColor: o.hostColor, isHost: true };
  }

  get open(): boolean {
    return this.isOpen;
  }
  get guestCount(): number {
    return this.guests.size;
  }
  members(): Peer[] {
    return [this.hostPeer, ...this.guests.values()];
  }
  subscribe(fn: (e: HostEvent) => void): () => void {
    this.listeners.add(fn);
    return () => this.listeners.delete(fn);
  }

  /** The transport calls this for every message from a connection. `m` is untrusted. */
  onMessage(conn: HostConn, m: unknown): void {
    if (!this.isOpen || typeof m !== "object" || m === null) return;
    const msg = m as Record<string, unknown>;
    if (msg.t === "join") this.handleJoin(conn, msg);
    else if (msg.t === "chat") this.handleChat(conn, msg);
    else if (msg.t === "leave") {
      this.onDisconnect(conn);
      conn.close();
    }
  }

  /** The transport calls this when a connection drops (or after the guest leaves). */
  onDisconnect(conn: HostConn): void {
    this.strikes.delete(conn);
    if (this.guests.delete(conn)) this.broadcastMembers();
  }

  /** The host types a message. Returns false if it is empty/too long or the room is closed. */
  sendHostChat(body: string): boolean {
    const text = cleanChat(body);
    if (!this.isOpen || text === null) return false;
    this.publish(this.hostPeer, text);
    return true;
  }

  /** Closes the room: every guest is told, then disconnected. */
  close(): void {
    if (!this.isOpen) return;
    this.isOpen = false;
    const all = [...this.guests.keys()];
    this.guests.clear();
    for (const c of all) {
      c.send({ t: "closed" });
      c.close();
    }
    this.emit({ t: "members", members: this.members(), guests: 0, max: this.maxGuests });
  }

  private handleJoin(conn: HostConn, m: Record<string, unknown>): void {
    if (this.guests.has(conn)) return; // already inside
    if (this.now() < this.lockedUntil) return this.reject(conn, "locked");
    if (!isValidCodeFormat(m.code) || m.code !== this.code) return this.strike(conn);
    const info = cleanJoinInfo(m.info);
    if (!info) return this.reject(conn, "bad_request");
    if (this.guests.size >= this.maxGuests) return this.reject(conn, "full");

    const peer: Peer = { id: this.newId(), displayName: info.displayName, avatarColor: info.avatarColor, isHost: false };
    this.guests.set(conn, peer);
    conn.send({
      t: "joined",
      youId: peer.id,
      members: this.members(),
      guests: this.guests.size,
      max: this.maxGuests,
      history: [...this.history],
    });
    this.broadcastMembers(conn);
  }

  private handleChat(conn: HostConn, m: Record<string, unknown>): void {
    const peer = this.guests.get(conn);
    if (!peer) return; // not joined: ignore
    const text = cleanChat(m.body);
    if (text === null) return;
    this.publish(peer, text);
  }

  private publish(from: Peer, body: string): void {
    const msg: ChatMessage = { id: this.newId(), fromId: from.id, fromName: from.displayName, body, at: new Date(this.now()).toISOString() };
    this.history.push(msg);
    if (this.history.length > HISTORY_LIMIT) this.history.shift();
    for (const c of this.guests.keys()) c.send({ t: "chat", msg });
    this.emit({ t: "chat", msg });
  }

  private broadcastMembers(except?: HostConn): void {
    const members = this.members();
    const guests = this.guests.size;
    for (const c of this.guests.keys()) {
      if (c !== except) c.send({ t: "members", members, guests, max: this.maxGuests });
    }
    this.emit({ t: "members", members, guests, max: this.maxGuests });
  }

  private strike(conn: HostConn): void {
    const n = (this.strikes.get(conn) ?? 0) + 1;
    this.strikes.set(conn, n);
    this.globalStrikes++;
    if (this.globalStrikes >= GLOBAL_STRIKE_LIMIT) {
      this.globalStrikes = 0;
      this.lockedUntil = this.now() + LOCK_MS;
    }
    conn.send({ t: "rejected", reason: "bad_code" });
    if (n >= MAX_STRIKES_PER_CONN) {
      this.strikes.delete(conn);
      conn.close();
    }
  }

  private reject(conn: HostConn, reason: "full" | "bad_request" | "locked"): void {
    conn.send({ t: "rejected", reason });
    conn.close();
  }

  private emit(e: HostEvent): void {
    for (const fn of this.listeners) fn(e);
  }
}
