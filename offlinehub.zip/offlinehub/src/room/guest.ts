import { cleanChat, type ChatMessage, type ClientMsg, type JoinInfo, type Peer, type RejectReason } from "./protocol.ts";

/** The guest's connection to the host. The transport (Wi-Fi/hotspot) implements this. */
export interface GuestLink {
  send(m: ClientMsg): void;
  close(): void;
}

export type GuestState = "idle" | "joining" | "joined" | "rejected" | "closed";

export interface GuestSnapshot {
  state: GuestState;
  youId: string | null;
  members: Peer[];
  guests: number;
  max: number;
  messages: ChatMessage[];
  rejectReason: RejectReason | null;
}

const EMPTY: GuestSnapshot = { state: "idle", youId: null, members: [], guests: 0, max: 0, messages: [], rejectReason: null };

/** A joining phone's side of the room. Everything the host sends is treated as untrusted. */
export class RoomGuest {
  private link: GuestLink;
  private code: string;
  private info: JoinInfo;
  private snap: GuestSnapshot = EMPTY;
  private listeners = new Set<(s: GuestSnapshot) => void>();

  constructor(link: GuestLink, code: string, info: JoinInfo) {
    this.link = link;
    this.code = code;
    this.info = info;
  }

  get snapshot(): GuestSnapshot {
    return this.snap;
  }
  subscribe(fn: (s: GuestSnapshot) => void): () => void {
    this.listeners.add(fn);
    return () => this.listeners.delete(fn);
  }

  join(): void {
    if (this.snap.state !== "idle") return;
    this.set({ state: "joining" });
    this.link.send({ t: "join", code: this.code, info: this.info });
  }

  sendChat(body: string): boolean {
    const text = cleanChat(body);
    if (this.snap.state !== "joined" || text === null) return false;
    this.link.send({ t: "chat", body: text });
    return true;
  }

  leave(): void {
    if (this.snap.state === "closed") return;
    if (this.snap.state === "joined") this.link.send({ t: "leave" });
    this.set({ state: "closed" });
    this.link.close();
  }

  /** The transport calls this when the connection drops. */
  onDisconnected(): void {
    if (this.snap.state === "joined" || this.snap.state === "joining") this.set({ state: "closed" });
  }

  /** The transport calls this for every message from the host. `m` is untrusted. */
  handle(m: unknown): void {
    if (typeof m !== "object" || m === null) return;
    const msg = m as Record<string, any>;
    if (msg.t === "joined" && this.snap.state === "joining" && Array.isArray(msg.members) && Array.isArray(msg.history)) {
      this.set({ state: "joined", youId: String(msg.youId), members: msg.members, guests: Number(msg.guests), max: Number(msg.max), messages: msg.history });
    } else if (msg.t === "rejected" && this.snap.state === "joining") {
      this.set({ state: "rejected", rejectReason: msg.reason as RejectReason });
    } else if (msg.t === "members" && this.snap.state === "joined" && Array.isArray(msg.members)) {
      this.set({ members: msg.members, guests: Number(msg.guests), max: Number(msg.max) });
    } else if (msg.t === "chat" && this.snap.state === "joined" && typeof msg.msg === "object" && msg.msg !== null) {
      this.set({ messages: [...this.snap.messages, msg.msg as ChatMessage] });
    } else if (msg.t === "closed" && this.snap.state === "joined") {
      this.set({ state: "closed" });
    }
  }

  private set(patch: Partial<GuestSnapshot>): void {
    this.snap = { ...this.snap, ...patch };
    for (const fn of this.listeners) fn(this.snap);
  }
}
