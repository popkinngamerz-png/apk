import { RoomGuest, type GuestLink } from "./guest.ts";
import type { JoinInfo } from "./protocol.ts";
import { DEFAULT_ROOM_PORT, type NativeHandle, type NativeRoom } from "./nativeTypes.ts";

export type JoinFailure = "not_found" | "connect_failed";

export class RoomNetError extends Error {
  readonly failure: JoinFailure;
  constructor(failure: JoinFailure, message: string) {
    super(message);
    this.failure = failure;
  }
}

export interface GuestSession {
  guest: RoomGuest;
  leave(): Promise<void>;
}

const noop = () => undefined;

/**
 * Joins a room. With no `ip`, the phone searches the local network for a host using this code.
 * With an `ip` (typed by the person), it connects straight to that phone.
 */
export async function joinRoomSession(
  native: NativeRoom,
  o: { code: string; info: JoinInfo; ip?: string; port?: number; searchMs?: number },
): Promise<GuestSession> {
  let ip = o.ip;
  let port = o.port ?? DEFAULT_ROOM_PORT;
  if (!ip) {
    const { hosts } = await native.discover({ code: o.code, timeoutMs: o.searchMs ?? 4000 });
    if (hosts.length === 0) {
      throw new RoomNetError("not_found", "No room with this code was found on this Wi-Fi/hotspot.");
    }
    ip = hosts[0].ip;
    port = hosts[0].port;
  }

  const link: GuestLink = {
    send: (m) => void native.guestSend({ line: JSON.stringify(m) }).catch(noop),
    close: () => void native.disconnect().catch(noop),
  };
  const guest = new RoomGuest(link, o.code, o.info);
  const handles: NativeHandle[] = [];
  const dropListeners = async () => {
    for (const h of handles) await h.remove().catch(noop);
    handles.length = 0;
  };

  try {
    handles.push(
      await native.addListener("guestLine", (d) => {
        let msg: unknown;
        try {
          msg = JSON.parse(String(d.line));
        } catch {
          return;
        }
        guest.handle(msg);
      }),
    );
    handles.push(await native.addListener("guestClosed", () => guest.onDisconnected()));
    try {
      await native.connect({ ip, port });
    } catch {
      throw new RoomNetError("connect_failed", "Could not reach the host phone. Check that you are on the same Wi-Fi/hotspot.");
    }
  } catch (e) {
    await dropListeners();
    throw e;
  }
  guest.join();
  return {
    guest,
    async leave() {
      guest.leave();
      await new Promise((r) => setTimeout(r, 100)); // let the goodbye message leave first
      await dropListeners();
    },
  };
}
