import { CODE_LENGTH } from "./protocol.ts";

/** Fills `n` random bytes. Replaceable in tests. */
export type RandomBytes = (n: number) => Uint8Array;

const defaultRandom: RandomBytes = (n) => crypto.getRandomValues(new Uint8Array(n));

/** A uniformly random 6-digit code ("000000" to "999999"), digits only. */
export function generateRoomCode(rand: RandomBytes = defaultRandom): string {
  let out = "";
  while (out.length < CODE_LENGTH) {
    // Rejection sampling: only bytes 0-249 are used, so every digit is equally likely.
    for (const b of rand(16)) {
      if (b < 250) out += String(b % 10);
      if (out.length === CODE_LENGTH) break;
    }
  }
  return out;
}

export function isValidCodeFormat(code: unknown): code is string {
  return typeof code === "string" && /^[0-9]{6}$/.test(code);
}

/** Keeps only digits and cuts to 6, for the code input box ("123 456" becomes "123456"). */
export function normalizeCodeInput(raw: string): string {
  return raw.replace(/\D/g, "").slice(0, CODE_LENGTH);
}
