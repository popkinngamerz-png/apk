// The functions the Android plugin (plugins/offlinehub-room) offers to the app.
// Kept separate from the plugin wiring so the room logic can be tested without a phone.

/** Port a host listens on unless it was busy (the host answers discovery with the real port). */
export const DEFAULT_ROOM_PORT = 47653;

export interface NativeHandle {
  remove(): Promise<void>;
}

export interface FoundHost {
  ip: string;
  port: number;
}

export interface NativeRoom {
  getLocalAddresses(): Promise<{ addresses: string[] }>;
  startHost(o: { code: string }): Promise<{ port: number }>;
  stopHost(): Promise<void>;
  hostSend(o: { connId: string; line: string }): Promise<void>;
  hostClose(o: { connId: string }): Promise<void>;
  discover(o: { code: string; timeoutMs: number }): Promise<{ hosts: FoundHost[] }>;
  connect(o: { ip: string; port: number }): Promise<void>;
  guestSend(o: { line: string }): Promise<void>;
  disconnect(): Promise<void>;
  /**
   * Events: hostConn {connId}, hostLine {connId, line}, hostClosed {connId},
   *         guestLine {line}, guestClosed {}
   */
  addListener(eventName: string, listener: (data: any) => void): Promise<NativeHandle>;
}
