// Room protocol: the messages a host phone and guest phones exchange.
// Pure data + validation. No network code here (the transport is plugged in separately).

/** Guests that can join one room (the host is not counted). Change this one number to resize rooms. */
export const MAX_GUESTS = 4;
export const CODE_LENGTH = 6;
export const MAX_CHAT_LENGTH = 2000;
export const HISTORY_LIMIT = 100;

export interface Peer {
  id: string;
  displayName: string;
  avatarColor: string;
  isHost: boolean;
}

/** What a joining guest tells the host about itself. The host assigns the real id. */
export interface JoinInfo {
  displayName: string;
  avatarColor: string;
}

export interface ChatMessage {
  id: string;
  fromId: string;
  fromName: string;
  body: string;
  at: string;
}

export type RejectReason = "bad_code" | "full" | "bad_request" | "locked";

export type ClientMsg =
  | { t: "join"; code: string; info: JoinInfo }
  | { t: "chat"; body: string }
  | { t: "leave" };

export type ServerMsg =
  | { t: "joined"; youId: string; members: Peer[]; guests: number; max: number; history: ChatMessage[] }
  | { t: "rejected"; reason: RejectReason }
  | { t: "members"; members: Peer[]; guests: number; max: number }
  | { t: "chat"; msg: ChatMessage }
  | { t: "closed" };

const COLOR_RE = /^#[0-9a-fA-F]{6}$/;

/** Returns a cleaned JoinInfo, or null if the input is not acceptable. */
export function cleanJoinInfo(x: unknown): JoinInfo | null {
  if (typeof x !== "object" || x === null) return null;
  const o = x as Record<string, unknown>;
  if (typeof o.displayName !== "string" || typeof o.avatarColor !== "string") return null;
  const name = o.displayName.trim();
  if (name.length < 1 || name.length > 40) return null;
  if (!COLOR_RE.test(o.avatarColor)) return null;
  return { displayName: name, avatarColor: o.avatarColor };
}

/** Returns trimmed chat text, or null if it is empty or too long. */
export function cleanChat(x: unknown): string | null {
  if (typeof x !== "string") return null;
  const t = x.trim();
  if (t.length < 1 || t.length > MAX_CHAT_LENGTH) return null;
  return t;
}
