import { RoomHost, type HostConn } from "./host.ts";
import type { NativeHandle, NativeRoom } from "./nativeTypes.ts";

export interface HostSession {
  host: RoomHost;
  code: string;
  port: number;
  /** This phone's local addresses, shown so a guest can join by IP if the code search fails. */
  addresses: string[];
  stop(): Promise<void>;
}

const noop = () => undefined;

/** Opens a room on this phone: wires the Android plugin's connections into a RoomHost. */
export async function startHostSession(native: NativeRoom, o: { hostName: string; hostColor: string }): Promise<HostSession> {
  const host = new RoomHost({ hostName: o.hostName, hostColor: o.hostColor });
  const conns = new Map<string, HostConn>();
  const handles: NativeHandle[] = [];
  const dropListeners = async () => {
    for (const h of handles) await h.remove().catch(noop);
    handles.length = 0;
  };

  try {
    handles.push(
      await native.addListener("hostConn", (d) => {
        const connId = String(d.connId);
        conns.set(connId, {
          send: (m) => void native.hostSend({ connId, line: JSON.stringify(m) }).catch(noop),
          close: () => void native.hostClose({ connId }).catch(noop),
        });
      }),
    );
    handles.push(
      await native.addListener("hostLine", (d) => {
        const conn = conns.get(String(d.connId));
        if (!conn) return;
        let msg: unknown;
        try {
          msg = JSON.parse(String(d.line));
        } catch {
          return; // not JSON: ignore
        }
        host.onMessage(conn, msg);
      }),
    );
    handles.push(
      await native.addListener("hostClosed", (d) => {
        const id = String(d.connId);
        const conn = conns.get(id);
        conns.delete(id);
        if (conn) host.onDisconnect(conn);
      }),
    );
    const { port } = await native.startHost({ code: host.code });
    const { addresses } = await native.getLocalAddresses().catch(() => ({ addresses: [] as string[] }));
    return {
      host,
      code: host.code,
      port,
      addresses,
      async stop() {
        host.close(); // tells every guest, then asks the plugin to close their connections
        await new Promise((r) => setTimeout(r, 150)); // let those goodbye messages leave first
        await native.stopHost().catch(noop);
        await dropListeners();
        conns.clear();
      },
    };
  } catch (e) {
    await dropListeners();
    throw e;
  }
}
